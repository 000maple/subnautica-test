# scores
scoreboard objectives add fktool dummy

# init
function fkfdtool:utils/set_constants
function fkfdtool:utils/tellraw
function fkfdtool:rng/get
function fkfdtool:warnings/get
