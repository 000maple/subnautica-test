# project
data modify storage fkfd:text project.name set value "FoodDecay"
data modify storage fkfd:text project.compatibility set value "26.1+"
data modify storage fkfd:text project.print set value [{"text":"[","bold":true,"color":"gold","hover_event":{"action":"show_text","value":[{"storage":"fktool:info","nbt":"load.devby","interpret":true}]}},{"storage":"fkfd:text","nbt":"project.name","interpret":true,"bold":true,"color":"gold"},{"text":"] ","bold":true,"color":"gold","hover_event":{"action":"show_text","value":[{"storage":"fktool:info","nbt":"load.devby","interpret":true}]}}]

# scores
scoreboard objectives add fkfd.options dummy {"text":"FoodDecay Options","color":"#cc4400"}
scoreboard objectives add fkfd.container.barrel minecraft.custom:minecraft.open_barrel {"text":"fkfd.container.barrel","color":"#cc4400"}
scoreboard objectives add fkfd.container.chest minecraft.custom:minecraft.open_chest {"text":"fkfd.container.chest","color":"#cc4400"}
scoreboard objectives add fkfd.container.trapped minecraft.custom:minecraft.trigger_trapped_chest {"text":"fkfd.container.trapped","color":"#cc4400"}
scoreboard objectives add fkfd.container.shulker minecraft.custom:minecraft.open_shulker_box {"text":"fkfd.container.shulker","color":"#cc4400"}
scoreboard objectives add fkfd.container.hopper minecraft.custom:minecraft.inspect_hopper {"text":"fkfd.container.hopper","color":"#cc4400"}
scoreboard objectives add fkfd.container.dropper minecraft.custom:minecraft.inspect_dropper {"text":"fkfd.container.dropper","color":"#cc4400"}
scoreboard objectives add fkfd.container.dispenser minecraft.custom:minecraft.inspect_dispenser {"text":"fkfd.container.dispenser","color":"#cc4400"}
scoreboard objectives add fkfd.container.furnace minecraft.custom:minecraft.interact_with_furnace {"text":"fkfd.container.furnace","color":"#cc4400"}
scoreboard objectives add fkfd.container.bfurnace minecraft.custom:minecraft.interact_with_blast_furnace {"text":"fkfd.container.bfurnace","color":"#cc4400"}
scoreboard objectives add fkfd.container.smoker minecraft.custom:minecraft.interact_with_smoker {"text":"fkfd.container.smoker","color":"#cc4400"}
#scoreboard objectives add fkfd.container.place_pot minecraft.used:minecraft.decorated_pot {"text":"fkfd.container.place_pot","color":"#cc4400"}

# config
function fkfd:lang/us
function fkfd:properties
function fkfd:schedules/list

# const
scoreboard players set decay.container.raycast.imax fkfd.options 30

# reset


# display
tellraw @a ["",{"storage":"fkfd:text","nbt":"project.print","interpret":true},{"storage":"fktool:info","nbt":"load.enabled","interpret":true},{"text":" ("},{"storage":"fkfd:text","nbt":"project.compatibility","interpret":true},{"text":"). "},{"storage":"fktool:info","nbt":"load.options","interpret":true},{"text":"[click here]","bold":true,"color":"aqua","click_event":{"action":"suggest_command","command":"/function fkfd:options/get"}}]
tellraw @a ["",{"storage":"fkfd:text","nbt":"project.print","interpret":true},{"storage":"fktool:info","nbt":"load.networks","interpret":true}]
tellraw @a ["",{"storage":"fkfd:text","nbt":"project.print","interpret":true},{"storage":"fktool:info","nbt":"load.free","interpret":true}]
