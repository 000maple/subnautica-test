### FoodDecay Datapack
###
### Developped by FunkyToc
### With love
### And a big amount of time



## Global

# Global datapack ON/OFF
# 0: datapack OFF
# 1: datapack ON
execute unless score global.enable fkfd.options matches 0.. run scoreboard players set global.enable fkfd.options 1


## Loot

# Global loot system ON/OFF
# Default: 1
# 0: disabled
# 1: enabled
execute unless score loot.global fkfd.options matches 0.. run scoreboard players set loot.global fkfd.options 1

# Food loot modified in hands
# Default: 1
# 0: disabled
# 1: enabled
execute unless score loot.in.hands fkfd.options matches 0.. run scoreboard players set loot.in.hands fkfd.options 1

# Food loot modified in hotbar
# Default: 1
# 0: disabled
# 1: enabled
execute unless score loot.in.hotbar fkfd.options matches 0.. run scoreboard players set loot.in.hotbar fkfd.options 1

# Food loot modified in inventory
# Default: 1
# 0: disabled
# 1: enabled
execute unless score loot.in.inventory fkfd.options matches 0.. run scoreboard players set loot.in.inventory fkfd.options 1


## Decay

# Global decay system ON/OFF
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.global fkfd.options matches 0.. run scoreboard players set decay.global fkfd.options 1

# Food decay frequency (seconds)
# Default: 60
# Range: 1 - 999
execute unless score decay.frequency fkfd.options matches 0.. run scoreboard players set decay.frequency fkfd.options 60

# Food decay in player's inventory
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.player fkfd.options matches 0.. run scoreboard players set decay.in.player fkfd.options 1

# Food decay in offhand
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.player.offhand fkfd.options matches 0.. run scoreboard players set decay.in.player.offhand fkfd.options 1

# Food decay in hotbar
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.player.hotbar fkfd.options matches 0.. run scoreboard players set decay.in.player.hotbar fkfd.options 1

# Food decay in inventory
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.player.inventory fkfd.options matches 0.. run scoreboard players set decay.in.player.inventory fkfd.options 1

# Food decay in enderchest
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.player.enderchest fkfd.options matches 0.. run scoreboard players set decay.in.player.enderchest fkfd.options 1

# Food decay in entities (chest_boats, chest_minecart, donkey...)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.entity fkfd.options matches 0.. run scoreboard players set decay.in.entity fkfd.options 1

# Food decay in boat
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.entity.boat fkfd.options matches 0.. run scoreboard players set decay.in.entity.boat fkfd.options 1

# Food decay in minecart
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.entity.minecart fkfd.options matches 0.. run scoreboard players set decay.in.entity.minecart fkfd.options 1

# Food decay in donkey
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.entity.donkey fkfd.options matches 0.. run scoreboard players set decay.in.entity.donkey fkfd.options 1

# Food decay in containers (chest, barrel, shulker...)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.container fkfd.options matches 0.. run scoreboard players set decay.in.container fkfd.options 1

# Food decay in barrel
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.container.barrel fkfd.options matches 0.. run scoreboard players set decay.in.container.barrel fkfd.options 1

# Food decay in chest
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.container.chest fkfd.options matches 0.. run scoreboard players set decay.in.container.chest fkfd.options 1

# Food decay in trapped chest
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.container.trapped fkfd.options matches 0.. run scoreboard players set decay.in.container.trapped fkfd.options 1

# Food decay in shulker
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.in.container.shulker fkfd.options matches 0.. run scoreboard players set decay.in.container.shulker fkfd.options 1

# Allow container to be cooled with ice (1-5 ice block), reducing the decay rate
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.container.fridge fkfd.options matches 0.. run scoreboard players set decay.container.fridge fkfd.options 1

# Display particles on cold containers
# Default: 1
# 0: disabled
# 1: enabled
execute unless score decay.container.fridge.fx fkfd.options matches 0.. run scoreboard players set decay.container.fridge.fx fkfd.options 1

# Frequency of the particles on cold/hot containers (second)
# Default: 3
# Range: 1 - 3600
execute unless score decay.container.fridge.fx.frequency fkfd.options matches 0.. run scoreboard players set decay.container.fridge.fx.frequency fkfd.options 3


## Ate Decayed Food

# Decayed food eating gives negatives effect
# Default: 1
# 0: disabled
# 1: enabled
execute unless score ate.decayed.global fkfd.options matches 0.. run scoreboard players set ate.decayed.global fkfd.options 1

# Quick hunger chance (- 1/2 food point) when eating a decayed food (%)
# Default: 80
# Range: 0 - 100
execute unless score ate.decayed.hunger fkfd.options matches 0.. run scoreboard players set ate.decayed.hunger fkfd.options 80

# Weakness chance (60s level 0) when eating a decayed food (%)
# Default: 20
# Range: 0 - 100
execute unless score ate.decayed.weakness fkfd.options matches 0.. run scoreboard players set ate.decayed.weakness fkfd.options 20

# Poisonning chance (3s level 0) when eating a decayed food (%)
# Default: 10
# Range: 0 - 100
execute unless score ate.decayed.poison fkfd.options matches 0.. run scoreboard players set ate.decayed.poison fkfd.options 10


## Ate Fresh Food

# Decayed food eating gives negatives effect
# Default: 1
# 0: disabled
# 1: enabled
execute unless score ate.fresh.global fkfd.options matches 0.. run scoreboard players set ate.fresh.global fkfd.options 1

# Quick saturation chance (+ 1/2 food point) when eating a fresh food (%)
# Default: 80
# Range: 0 - 100
execute unless score ate.fresh.saturation fkfd.options matches 0.. run scoreboard players set ate.fresh.saturation fkfd.options 80

# Haste chance (60s level 0) when eating a fresh food (%)
# Default: 20
# Range: 0 - 100
execute unless score ate.fresh.haste fkfd.options matches 0.. run scoreboard players set ate.fresh.haste fkfd.options 20

# Resistance chance (60s level 0) when eating a fresh food (%)
# Default: 10
# Range: 0 - 100
execute unless score ate.fresh.resistance fkfd.options matches 0.. run scoreboard players set ate.fresh.resistance fkfd.options 10
