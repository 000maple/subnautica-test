scoreboard objectives remove fkfd.options
scoreboard objectives remove fkfd.container.barrel
scoreboard objectives remove fkfd.container.chest
scoreboard objectives remove fkfd.container.trapped
scoreboard objectives remove fkfd.container.shulker
scoreboard objectives remove fkfd.container.hopper
scoreboard objectives remove fkfd.container.dropper
scoreboard objectives remove fkfd.container.dispenser
scoreboard objectives remove fkfd.container.furnace
scoreboard objectives remove fkfd.container.bfurnace
scoreboard objectives remove fkfd.container.smoker

function fkfdtool:uninstall

give @s minecraft:command_block[custom_name={"color":"#AF91FF","italic":false,"text":"Sparkles: Marker Remover"},lore=[{"color":"white","italic":false,"text":"Hide this command_block at your spawn for a few days."},{"color":"white","italic":false,"text":"It will kill remaining markers when they are loaded."},{"color":"red","italic":false,"text":"Require \"Repeat & Always Active\" mode."}],block_entity_data={id:"command_block",auto:1b,Command:"kill @e[type=minecraft:marker,tag=fkfd.decay.container]"}]

tellraw @s ["",{"text":"[FoodDecay] ","bold":true,"color":"gold"},{"text":"Uninstalled.","color":"red"},{"text":" Don't forget to ","color":"red"},{"text":"[disable datapack]","bold":true,"color":"aqua","click_event":{"action":"suggest_command","command":"/datapack disable \"file/FoodDecay"}}]
