# use: tellraw @a[tag=fkdev] {"storage":"fkfd:text","nbt":"log.loot.process.error","interpret":true}

# custom names
data modify storage fkfd:text customname.rotten_food.name set value [{"text":"Rotten Food","color":"white"}]

# log
data modify storage fkfd:text log.loot.give set value [{"text":"fooddecay.log: ","color":"red"},{"selector":"@s","color":"gray"},{"text":" -> loot give","color":"white"}]
data modify storage fkfd:text log.loot.drop set value [{"text":"fooddecay.log: ","color":"red"},{"selector":"@s","color":"gray"},{"text":" -> loot drop","color":"white"}]
data modify storage fkfd:text log.container.marker set value [{"text":"fooddecay.log: ","color":"red"},{"selector":"@s","color":"gray"},{"text":" -> summon new decay marker","color":"white"}]

# debug
data modify storage fkfd:text log.loot.process.error set value [{"text":"fooddecay.error: ","color":"red"},{"selector":"@s","color":"gray"},{"text":" -> unknown/empty item to process","color":"white"}]
