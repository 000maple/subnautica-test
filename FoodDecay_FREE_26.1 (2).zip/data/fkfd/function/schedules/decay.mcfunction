# coroutine
schedule function fkfd:schedules/decay 1s

# canceler


# inventory
execute if score #DecayLoop fkfd.options matches ..0 run function fkfd:systems/decay/loop
execute if score #DecayLoop fkfd.options matches ..0 run scoreboard players operation #DecayLoop fkfd.options = #60 fktool
scoreboard players remove #DecayLoop fkfd.options 1

# container fx
execute if score #ContainerDecayFxLoop fkfd.options matches ..0 run function fkfd:systems/decay/container/fx/loop
execute if score #ContainerDecayFxLoop fkfd.options matches ..0 run scoreboard players operation #ContainerDecayFxLoop fkfd.options = #3 fktool
scoreboard players remove #ContainerDecayFxLoop fkfd.options 1
