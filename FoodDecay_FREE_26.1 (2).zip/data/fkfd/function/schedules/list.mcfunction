function fkfd:schedules/decay
function fkfd:schedules/cleaner
