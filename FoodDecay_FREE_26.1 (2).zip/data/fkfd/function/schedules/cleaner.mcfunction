# reset adv
execute as @a run function fkfd:systems/loot/inventory/adv_reset

# clean decay marker
execute as @e[type=minecraft:marker,tag=fkfd.decay.container] at @s unless block ~ ~ ~ #fkfd:container/decay run kill @s

# coroutine
schedule function fkfd:schedules/cleaner 600s
