advancement revoke @s only fkfd:ate_fresh

# canceler
execute if score ate.fresh.global fkfd.options matches 0 run return fail



# up the saturation effect
function fkfdtool:rng/get
execute if score Random fktool < #80 fktool run effect give @s minecraft:saturation 1 0 true

# haste chance
function fkfdtool:rng/get
execute if score Random fktool < #20 fktool run effect give @s minecraft:haste 60 0 false

# resistance chance
function fkfdtool:rng/get
execute if score Random fktool < #10 fktool run effect give @s minecraft:resistance 60 0 false
