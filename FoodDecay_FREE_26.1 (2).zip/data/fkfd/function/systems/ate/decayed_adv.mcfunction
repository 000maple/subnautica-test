advancement revoke @s only fkfd:ate_decayed

# canceler
execute if score ate.decayed.global fkfd.options matches 0 run return fail



# down the saturation effect
function fkfdtool:rng/get
execute if score Random fktool < #80 fktool run effect give @s minecraft:hunger 1 40 true

# weakness chance
function fkfdtool:rng/get
execute if score Random fktool < #20 fktool run effect give @s minecraft:weakness 60 0 false

# poisonning chance
function fkfdtool:rng/get
execute if score Random fktool < #10 fktool run effect give @s minecraft:poison 3 0 false
