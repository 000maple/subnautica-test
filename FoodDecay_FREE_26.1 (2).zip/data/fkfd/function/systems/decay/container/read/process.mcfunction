# if rotten
$execute if items block ~ ~ ~ $(slot) #fkfd:food[minecraft:damage=10000] run return run function fkfd:systems/decay/container/action/rotten {slot:"$(slot)"}

# if frozen
$execute if entity @s[tag=fkfd.container.frozen] run return run function fkfd:systems/decay/container/process/frozen {slot:"$(slot)"}

# if cold
$execute if entity @s[tag=fkfd.container.cold] run return run function fkfd:systems/decay/container/process/cold {slot:"$(slot)"}

# if hot
$execute if entity @s[tag=fkfd.container.hot] run return run function fkfd:systems/decay/container/process/hot {slot:"$(slot)"}

# if normal
$function fkfd:systems/decay/container/process/normal {slot:"$(slot)"}
