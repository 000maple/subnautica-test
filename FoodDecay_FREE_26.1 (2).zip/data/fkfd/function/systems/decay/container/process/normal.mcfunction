$execute if items block ~ ~ ~ $(slot) #fkfd:decay/very_fast run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"05"}
$execute if items block ~ ~ ~ $(slot) #fkfd:decay/fast run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"02"}
$execute if items block ~ ~ ~ $(slot) #fkfd:decay/medium run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"01"}
$execute if items block ~ ~ ~ $(slot) #fkfd:decay/slow run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"0_2"}
$execute if items block ~ ~ ~ $(slot) #fkfd:decay/very_slow run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"0_05"}
$execute if items block ~ ~ ~ $(slot) #fkfd:decay/imperishable if predicate fkfdtool:rng/05 run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"0_01"}
