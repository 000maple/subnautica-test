$execute if items block ~ ~ ~ $(slot) #fkfd:decay/very_fast run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"10"}
$execute if items block ~ ~ ~ $(slot) #fkfd:decay/fast run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"05"}
$execute if items block ~ ~ ~ $(slot) #fkfd:decay/medium run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"03"}
$execute if items block ~ ~ ~ $(slot) #fkfd:decay/slow run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"0_5"}
$execute if items block ~ ~ ~ $(slot) #fkfd:decay/very_slow run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"0_2"}
$execute if items block ~ ~ ~ $(slot) #fkfd:decay/imperishable if predicate fkfdtool:rng/50 run return run function fkfd:systems/decay/container/action/rotting {slot:"$(slot)",force:"0_02"}
