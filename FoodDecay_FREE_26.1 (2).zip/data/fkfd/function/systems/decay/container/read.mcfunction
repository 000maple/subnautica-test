# decay
execute if block ~ ~ ~ minecraft:barrel run return run function fkfd:systems/decay/container/read/single
execute if block ~ ~ ~ minecraft:chest run return run function fkfd:systems/decay/container/read/double
execute if block ~ ~ ~ minecraft:trapped_chest run return run function fkfd:systems/decay/container/read/double
execute if block ~ ~ ~ #minecraft:shulker_boxes run return run function fkfd:systems/decay/container/read/single
