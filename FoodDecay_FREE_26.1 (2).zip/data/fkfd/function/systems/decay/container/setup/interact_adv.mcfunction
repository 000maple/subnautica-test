# resets
advancement revoke @s only fkfd:container_interaction
function fkfd:systems/decay/container/setup/reset_score

# find container
execute anchored eyes positioned ^ ^ ^.3 run function fkfd:systems/decay/container/setup/raycast/init
