# double
execute if block ~ ~ ~ #fkfd:container/type/double[type=left,facing=north] positioned ~1 ~ ~ run return run function fkfd:systems/decay/container/setup/summon/marker
execute if block ~ ~ ~ #fkfd:container/type/double[type=left,facing=west] positioned ~ ~ ~-1 run return run function fkfd:systems/decay/container/setup/summon/marker
execute if block ~ ~ ~ #fkfd:container/type/double[type=left,facing=south] positioned ~-1 ~ ~ run return run function fkfd:systems/decay/container/setup/summon/marker
execute if block ~ ~ ~ #fkfd:container/type/double[type=left,facing=east] positioned ~ ~ ~1 run return run function fkfd:systems/decay/container/setup/summon/marker

# simple
function fkfd:systems/decay/container/setup/summon/marker
