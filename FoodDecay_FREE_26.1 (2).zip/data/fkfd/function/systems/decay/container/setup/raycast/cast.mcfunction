# check
execute if block ~ ~ ~ #fkfd:container/decay align xyz positioned ~.5 ~.5 ~.5 run return run function fkfd:systems/decay/container/setup/raycast/found

# i++
scoreboard players add #tmp.steps fkfd.options 1
#particle minecraft:wax_off

# cast
execute if score #tmp.steps fkfd.options < #40 fktool positioned ^ ^ ^.2 run function fkfd:systems/decay/container/setup/raycast/cast
