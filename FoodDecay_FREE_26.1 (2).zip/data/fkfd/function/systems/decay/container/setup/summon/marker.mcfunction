# summon
summon minecraft:marker ~ ~ ~ {Tags:["fkfd.decay.container","fkfd.decay.container.init"]}

# tags
execute as @n[type=minecraft:marker,tag=fkfd.decay.container.init,sort=nearest,distance=...1] at @s run function fkfd:systems/decay/container/setup/summon/tags_set

# reset
tag @n[tag=fkfd.decay.container.init,sort=nearest] remove fkfd.decay.container.init

# log
tellraw @a[tag=fkdev] {"storage":"fkfd:text","nbt":"log.container.marker","interpret":true}
