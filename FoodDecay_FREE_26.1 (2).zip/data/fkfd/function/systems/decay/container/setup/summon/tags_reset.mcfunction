tag @s remove fkfd.container.frozen
tag @s remove fkfd.container.cold
tag @s remove fkfd.container.hot
tag @s remove fkfd.container.double
