# init
scoreboard players set #tmp.steps fkfd.options 0

function fkfd:systems/decay/container/setup/raycast/cast
