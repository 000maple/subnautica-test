function fkfd:systems/decay/container/setup/checks
#particle minecraft:flame
