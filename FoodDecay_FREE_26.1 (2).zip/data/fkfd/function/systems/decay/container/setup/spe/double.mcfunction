execute if block ~ ~ ~ #fkfd:container/type/double[facing=north] positioned ~1 ~ ~ if entity @n[type=minecraft:marker,tag=fkfd.decay.container,distance=...1] run return 1
execute if block ~ ~ ~ #fkfd:container/type/double[facing=west] positioned ~ ~ ~-1 if entity @n[type=minecraft:marker,tag=fkfd.decay.container,distance=...1] run return 1
execute if block ~ ~ ~ #fkfd:container/type/double[facing=south] positioned ~-1 ~ ~ if entity @n[type=minecraft:marker,tag=fkfd.decay.container,distance=...1] run return 1
execute if block ~ ~ ~ #fkfd:container/type/double[facing=east] positioned ~ ~ ~1 if entity @n[type=minecraft:marker,tag=fkfd.decay.container,distance=...1] run return 1

return 0
