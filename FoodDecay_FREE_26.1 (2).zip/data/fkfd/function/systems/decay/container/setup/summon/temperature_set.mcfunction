# init
scoreboard players set #tmp fkfd.options 0

# is fridge
execute if block ~ ~-1 ~ #fkfd:container/cold run scoreboard players remove #tmp fkfd.options 1
execute if block ~ ~01 ~ #fkfd:container/cold run scoreboard players remove #tmp fkfd.options 1
execute if block ~-1 ~ ~ #fkfd:container/cold run scoreboard players remove #tmp fkfd.options 1
execute if block ~01 ~ ~ #fkfd:container/cold run scoreboard players remove #tmp fkfd.options 1
execute if block ~ ~ ~-1 #fkfd:container/cold run scoreboard players remove #tmp fkfd.options 1
execute if block ~ ~ ~01 #fkfd:container/cold run scoreboard players remove #tmp fkfd.options 1

# is hot
execute if block ~ ~-1 ~ #fkfd:container/hot run scoreboard players add #tmp fkfd.options 1
execute if block ~ ~01 ~ #fkfd:container/hot run scoreboard players add #tmp fkfd.options 1
execute if block ~-1 ~ ~ #fkfd:container/hot run scoreboard players add #tmp fkfd.options 1
execute if block ~01 ~ ~ #fkfd:container/hot run scoreboard players add #tmp fkfd.options 1
execute if block ~ ~ ~-1 #fkfd:container/hot run scoreboard players add #tmp fkfd.options 1
execute if block ~ ~ ~01 #fkfd:container/hot run scoreboard players add #tmp fkfd.options 1

# result
execute if score #tmp fkfd.options matches ..-005 run return run tag @s add fkfd.container.frozen
execute if score #tmp fkfd.options matches -4..-1 run return run tag @s add fkfd.container.cold
execute if score #tmp fkfd.options matches 0001.. run return run tag @s add fkfd.container.hot
