# reset
function fkfd:systems/decay/container/setup/summon/tags_reset

# double
execute if block ~ ~ ~ #fkfd:container/type/double[type=right] run tag @s add fkfd.double

# temperature
execute run function fkfd:systems/decay/container/setup/summon/temperature_set
