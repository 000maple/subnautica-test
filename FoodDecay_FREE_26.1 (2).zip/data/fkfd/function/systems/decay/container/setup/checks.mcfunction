## container checks, as player at container

# simple
execute if entity @n[type=minecraft:marker,tag=fkfd.decay.container,distance=...1] run return fail

# double
execute if block ~ ~ ~ #fkfd:container/type/double[type=left] store result score #tmp fkfd.options run function fkfd:systems/decay/container/setup/spe/double
execute if score #tmp fkfd.options matches 1 run return fail

## summon
function fkfd:systems/decay/container/setup/summon/types
