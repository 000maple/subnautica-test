# clear rotten
$item replace block ~ ~ ~ $(slot) with minecraft:air
