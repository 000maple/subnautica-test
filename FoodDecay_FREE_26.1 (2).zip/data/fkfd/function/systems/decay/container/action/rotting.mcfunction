# rotting damage
$item modify block ~ ~ ~ $(slot) fkfd:damage/add/$(force)
