# exceptions
$execute if items block ~ ~ ~ $(slot) #fkfd:spe/bucket run return run item replace block ~ ~ ~ $(slot) with minecraft:bucket
$execute if items block ~ ~ ~ $(slot) #fkfd:spe/bottle run return run item replace block ~ ~ ~ $(slot) with minecraft:glass_bottle

# into rotten food
$item replace block ~ ~ ~ $(slot) with minecraft:rotten_flesh[custom_name={"italic":false,"text":"Rotten Food"},max_stack_size=1]
