# check container
execute as @e[type=minecraft:marker,tag=fkfd.decay.container,tag=fkfd.container.check,limit=3] at @s run function fkfd:systems/decay/container/check


execute if entity @n[type=minecraft:marker,tag=fkfd.container.check] run schedule function fkfd:systems/decay/container/loop 2t
