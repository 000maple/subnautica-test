## as marker at @s

# if no more container
execute unless block ~ ~ ~ #fkfd:container/decay run return run kill @s

# update local temperature
function fkfd:systems/decay/container/setup/summon/tags_set

# read container
execute if items block ~ ~ ~ container.* #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/container/read

# reset
tag @s remove fkfd.container.check
