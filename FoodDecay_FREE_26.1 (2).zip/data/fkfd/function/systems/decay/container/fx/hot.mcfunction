particle minecraft:dust_color_transition{from_color:[1.0,0.7,0.7],to_color:[1.0,0.6,0.6],scale:1.5f} ~ ~ ~ .35 .35 .35 0 1 normal
