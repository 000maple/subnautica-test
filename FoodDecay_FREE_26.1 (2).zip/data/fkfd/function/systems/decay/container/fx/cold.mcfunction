particle minecraft:dust_color_transition{from_color:[0.9,0.9,1.0],to_color:[0.5,0.6,1.0],scale:2.0f} ~ ~ ~ .35 .35 .35 0 3 normal
