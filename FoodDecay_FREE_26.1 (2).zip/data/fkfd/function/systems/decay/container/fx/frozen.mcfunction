particle minecraft:dust_color_transition{from_color:[0.9,0.9,1.0],to_color:[0.6,0.7,1.0],scale:2.0f} ~ ~ ~ .4 .4 .4 0 8 normal
particle minecraft:block{block_state:"minecraft:packed_ice"} ~ ~ ~ .3 .3 .3 0 3 normal
