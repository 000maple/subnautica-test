execute if entity @s[tag=fkfd.container.frozen] run return run function fkfd:systems/decay/container/fx/frozen
execute if entity @s[tag=fkfd.container.cold] run return run function fkfd:systems/decay/container/fx/cold
execute if entity @s[tag=fkfd.container.hot] run return run function fkfd:systems/decay/container/fx/hot
