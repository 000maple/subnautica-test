# container fx
execute at @a as @e[type=minecraft:marker,tag=fkfd.decay.container,sort=nearest,distance=..32] at @s run function fkfd:systems/decay/container/fx/chose
