# canceler
execute store result score #tmp fkfd.options run clear @s #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] 0
execute if score #tmp fkfd.options matches 0 run return 0

# read
execute if items entity @s weapon.* #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/weapon
execute if items entity @s hotbar.* #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/hotbar
execute if items entity @s inventory.* #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/inventory
execute if items entity @s enderchest.* #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/enderchest
#execute if items entity @s horse.* #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/horse ##bugged for now
