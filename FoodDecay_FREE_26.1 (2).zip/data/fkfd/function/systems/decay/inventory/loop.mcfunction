# check inventory
execute as @p[tag=fkfd.inventory.check] run function fkfd:systems/decay/inventory/check


execute if entity @p[tag=fkfd.inventory.check] run schedule function fkfd:systems/decay/inventory/loop 2t
