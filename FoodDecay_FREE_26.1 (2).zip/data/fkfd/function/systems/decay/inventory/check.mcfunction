## as player at @s

# read inventory
function fkfd:systems/decay/inventory/read

# reset
tag @s remove fkfd.inventory.check
