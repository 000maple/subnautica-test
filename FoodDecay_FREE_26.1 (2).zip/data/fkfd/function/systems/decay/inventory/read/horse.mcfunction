# slots
execute if items entity @s horse.0 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.0"}
execute if items entity @s horse.1 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.1"}
execute if items entity @s horse.2 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.2"}
execute if items entity @s horse.3 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.3"}
execute if items entity @s horse.4 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.4"}

execute if items entity @s horse.5 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.5"}
execute if items entity @s horse.6 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.6"}
execute if items entity @s horse.7 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.7"}
execute if items entity @s horse.8 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.8"}
execute if items entity @s horse.9 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.9"}

execute if items entity @s horse.10 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.10"}
execute if items entity @s horse.11 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.11"}
execute if items entity @s horse.12 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.12"}
execute if items entity @s horse.13 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.13"}
execute if items entity @s horse.14 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"horse.14"}
