# slots
execute if items entity @s inventory.0 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.0"}
execute if items entity @s inventory.1 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.1"}
execute if items entity @s inventory.2 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.2"}
execute if items entity @s inventory.3 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.3"}
execute if items entity @s inventory.4 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.4"}
execute if items entity @s inventory.5 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.5"}
execute if items entity @s inventory.6 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.6"}
execute if items entity @s inventory.7 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.7"}
execute if items entity @s inventory.8 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.8"}
execute if items entity @s inventory.9 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.9"}

execute if items entity @s inventory.10 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.10"}
execute if items entity @s inventory.11 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.11"}
execute if items entity @s inventory.12 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.12"}
execute if items entity @s inventory.13 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.13"}
execute if items entity @s inventory.14 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.14"}
execute if items entity @s inventory.15 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.15"}
execute if items entity @s inventory.16 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.16"}
execute if items entity @s inventory.17 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.17"}

execute if items entity @s inventory.18 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.18"}
execute if items entity @s inventory.19 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.19"}
execute if items entity @s inventory.20 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.20"}
execute if items entity @s inventory.21 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.21"}
execute if items entity @s inventory.22 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.22"}
execute if items entity @s inventory.23 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.23"}
execute if items entity @s inventory.24 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.24"}
execute if items entity @s inventory.25 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.25"}
execute if items entity @s inventory.26 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"inventory.26"}
