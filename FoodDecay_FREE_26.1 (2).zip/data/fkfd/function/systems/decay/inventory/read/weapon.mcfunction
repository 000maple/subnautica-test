# slots
execute if items entity @s weapon.offhand #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"weapon.offhand"}
