# slots
execute if items entity @s enderchest.0 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.0"}
execute if items entity @s enderchest.1 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.1"}
execute if items entity @s enderchest.2 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.2"}
execute if items entity @s enderchest.3 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.3"}
execute if items entity @s enderchest.4 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.4"}
execute if items entity @s enderchest.5 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.5"}
execute if items entity @s enderchest.6 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.6"}
execute if items entity @s enderchest.7 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.7"}
execute if items entity @s enderchest.8 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.8"}
execute if items entity @s enderchest.9 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.9"}

execute if items entity @s enderchest.10 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.10"}
execute if items entity @s enderchest.11 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.11"}
execute if items entity @s enderchest.12 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.12"}
execute if items entity @s enderchest.13 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.13"}
execute if items entity @s enderchest.14 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.14"}
execute if items entity @s enderchest.15 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.15"}
execute if items entity @s enderchest.16 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.16"}
execute if items entity @s enderchest.17 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.17"}
execute if items entity @s enderchest.18 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.18"}
execute if items entity @s enderchest.19 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.19"}

execute if items entity @s enderchest.20 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.20"}
execute if items entity @s enderchest.21 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.21"}
execute if items entity @s enderchest.22 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.22"}
execute if items entity @s enderchest.23 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.23"}
execute if items entity @s enderchest.24 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.24"}
execute if items entity @s enderchest.25 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.25"}
execute if items entity @s enderchest.26 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"enderchest.26"}
