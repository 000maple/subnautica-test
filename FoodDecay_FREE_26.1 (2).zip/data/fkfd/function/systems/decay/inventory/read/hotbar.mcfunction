# slots
execute if items entity @s hotbar.0 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"hotbar.0"}
execute if items entity @s hotbar.1 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"hotbar.1"}
execute if items entity @s hotbar.2 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"hotbar.2"}
execute if items entity @s hotbar.3 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"hotbar.3"}
execute if items entity @s hotbar.4 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"hotbar.4"}
execute if items entity @s hotbar.5 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"hotbar.5"}
execute if items entity @s hotbar.6 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"hotbar.6"}
execute if items entity @s hotbar.7 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"hotbar.7"}
execute if items entity @s hotbar.8 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/inventory/read/process {slot:"hotbar.8"}
