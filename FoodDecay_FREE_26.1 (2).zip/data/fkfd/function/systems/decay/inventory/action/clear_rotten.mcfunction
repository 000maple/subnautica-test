# clear rotten
clear @s #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}},minecraft:damage=10000]
