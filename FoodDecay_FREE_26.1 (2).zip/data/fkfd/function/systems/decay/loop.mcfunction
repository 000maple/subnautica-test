# inventory

tag @a[gamemode=!spectator,gamemode=!creative] add fkfd.inventory.check
schedule function fkfd:systems/decay/inventory/loop 1s append

# container

tag @e[type=minecraft:marker,tag=fkfd.decay.container] add fkfd.container.check
schedule function fkfd:systems/decay/container/loop 2s append

# entity

tag @e[type=#fkfd:decay/entities] add fkfd.entity.check
schedule function fkfd:systems/decay/entity/loop 3s append

# item
#nah, not required, too laggy
