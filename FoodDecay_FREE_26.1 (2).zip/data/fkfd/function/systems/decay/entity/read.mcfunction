# decay
execute if entity @s[type=#fkfd:decay/chest_boats] run return run function fkfd:systems/decay/entity/read/single
execute if entity @s[type=minecraft:chest_minecart] run return run function fkfd:systems/decay/entity/read/single
execute if entity @s[type=minecraft:donkey] run return run function fkfd:systems/decay/entity/read/horse