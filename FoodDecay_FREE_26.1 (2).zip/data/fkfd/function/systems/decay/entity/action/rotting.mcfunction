# rotting damage
$item modify entity @s $(slot) fkfd:damage/add/$(force)
