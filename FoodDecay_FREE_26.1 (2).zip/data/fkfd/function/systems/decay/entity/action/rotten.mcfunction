# exceptions
$execute if items entity @s $(slot) #fkfd:spe/bucket run return run item replace entity @s $(slot) with minecraft:bucket
$execute if items entity @s $(slot) #fkfd:spe/bottle run return run item replace entity @s $(slot) with minecraft:glass_bottle

# into rotten food
$item replace entity @s $(slot) with minecraft:rotten_flesh[custom_name={"italic":false,"text":"Rotten Food"},max_stack_size=1]
