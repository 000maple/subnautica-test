# clear rotten
$item replace entity @s $(slot) with minecraft:air
