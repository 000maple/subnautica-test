## as entity at @s

# read entity
execute if items entity @s container.* #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read
execute if entity @s[type=minecraft:donkey] if items entity @s horse.* #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read

# reset
tag @s remove fkfd.entity.check
