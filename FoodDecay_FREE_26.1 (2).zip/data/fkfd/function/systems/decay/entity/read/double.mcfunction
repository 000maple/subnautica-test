# slots
execute if items entity @s container.0 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.0"}
execute if items entity @s container.1 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.1"}
execute if items entity @s container.2 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.2"}
execute if items entity @s container.3 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.3"}
execute if items entity @s container.4 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.4"}
execute if items entity @s container.5 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.5"}
execute if items entity @s container.6 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.6"}
execute if items entity @s container.7 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.7"}
execute if items entity @s container.8 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.8"}

execute if items entity @s container.9 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.9"}
execute if items entity @s container.10 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.10"}
execute if items entity @s container.11 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.11"}
execute if items entity @s container.12 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.12"}
execute if items entity @s container.13 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.13"}
execute if items entity @s container.14 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.14"}
execute if items entity @s container.15 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.15"}
execute if items entity @s container.16 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.16"}
execute if items entity @s container.17 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.17"}

execute if items entity @s container.18 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.18"}
execute if items entity @s container.19 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.19"}
execute if items entity @s container.20 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.20"}
execute if items entity @s container.21 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.21"}
execute if items entity @s container.22 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.22"}
execute if items entity @s container.23 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.23"}
execute if items entity @s container.24 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.24"}
execute if items entity @s container.25 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.25"}
execute if items entity @s container.26 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.26"}

execute if items entity @s container.27 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.27"}
execute if items entity @s container.28 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.28"}
execute if items entity @s container.29 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.29"}
execute if items entity @s container.30 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.30"}
execute if items entity @s container.31 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.31"}
execute if items entity @s container.32 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.32"}
execute if items entity @s container.33 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.33"}
execute if items entity @s container.34 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.34"}
execute if items entity @s container.35 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.35"}

execute if items entity @s container.36 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.36"}
execute if items entity @s container.37 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.37"}
execute if items entity @s container.38 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.38"}
execute if items entity @s container.39 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.39"}
execute if items entity @s container.40 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.40"}
execute if items entity @s container.41 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.41"}
execute if items entity @s container.42 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.42"}
execute if items entity @s container.43 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.43"}
execute if items entity @s container.44 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.44"}

execute if items entity @s container.45 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.45"}
execute if items entity @s container.46 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.46"}
execute if items entity @s container.47 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.47"}
execute if items entity @s container.48 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.48"}
execute if items entity @s container.49 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.49"}
execute if items entity @s container.50 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.50"}
execute if items entity @s container.51 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.51"}
execute if items entity @s container.52 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.52"}
execute if items entity @s container.53 #fkfd:food[minecraft:custom_data~{fkfd:{food:1b}}] run function fkfd:systems/decay/entity/read/process {slot:"container.53"}
