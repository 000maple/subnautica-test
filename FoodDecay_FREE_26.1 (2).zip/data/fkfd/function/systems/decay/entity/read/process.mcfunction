# if rotten
$execute if items entity @s $(slot) #fkfd:food[minecraft:damage=10000] run return run function fkfd:systems/decay/entity/action/rotten {slot:"$(slot)"}

# decay
$function fkfd:systems/decay/entity/process/normal {slot:"$(slot)"}
