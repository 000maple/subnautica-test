# check entity
execute as @e[type=#fkfd:decay/entities,tag=fkfd.entity.check,limit=3] at @s run function fkfd:systems/decay/entity/check


execute if entity @n[type=#fkfd:decay/entities,tag=fkfd.entity.check] run schedule function fkfd:systems/decay/entity/loop 2t
