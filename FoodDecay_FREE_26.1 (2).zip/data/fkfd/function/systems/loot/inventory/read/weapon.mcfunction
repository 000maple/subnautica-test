# slots
execute if items entity @s weapon.mainhand #fkfd:food[!minecraft:custom_data~{fkfd:{food:1b}}] run return run data modify storage fkfd:tmp item.data set from entity @s SelectedItem
execute if items entity @s weapon.offhand #fkfd:food[!minecraft:custom_data~{fkfd:{food:1b}}] run return run data modify storage fkfd:tmp item.data set from entity @s equipment.offhand
