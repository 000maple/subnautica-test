## DEPRECIATED: cannot copy previous data /!\

# clear
$clear @s $(id)[!minecraft:custom_data~{fkfd:{food:1b}}] 1

# give
$give @s $(id)[minecraft:custom_data~{fkfd:{food:1b}},max_stack_size=1,tooltip_display={hidden_components:["damage"]},damage=0,max_damage=10000]

#tellraw @a[tag=fkdev] {"storage":"fkfd:text","nbt":"log.loot.give","interpret":true}
