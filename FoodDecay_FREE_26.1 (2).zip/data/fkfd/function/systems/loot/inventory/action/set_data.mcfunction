# add required data
data merge entity @s {Item:{components:{"minecraft:custom_data":{fkfd:{food:1b}},"minecraft:max_stack_size":1,"minecraft:damage":0,"minecraft:max_damage":10000,"minecraft:tooltip_display":{hidden_components:["damage"]}}}}

tag @s remove fkfd.loot.init
