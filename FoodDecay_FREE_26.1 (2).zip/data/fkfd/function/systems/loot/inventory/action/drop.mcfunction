# clear
$clear @s $(id)[!minecraft:custom_data~{fkfd:{food:1b}}] 1

# drop food
$execute if data storage fkfd:tmp item.components run summon minecraft:item ~ ~ ~ {Item:{id:"$(id)",count:1,components:$(components)},Tags:[fkfd.loot.init]}
$execute unless data storage fkfd:tmp item.components run summon minecraft:item ~ ~ ~ {Item:{id:"$(id)",count:1},Tags:[fkfd.loot.init]}
execute as @n[type=minecraft:item,tag=fkfd.loot.init,sort=nearest] run function fkfd:systems/loot/inventory/action/set_data

#tellraw @a[tag=fkdev] {"storage":"fkfd:text","nbt":"log.loot.drop","interpret":true}
