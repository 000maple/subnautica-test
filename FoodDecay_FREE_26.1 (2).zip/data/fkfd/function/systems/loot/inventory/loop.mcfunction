# check loot
execute as @a[tag=fkfd.loot.check] at @s run function fkfd:systems/loot/inventory/check


execute if entity @p[tag=fkfd.loot.check] run schedule function fkfd:systems/loot/inventory/loop 1t
