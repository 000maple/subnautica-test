execute run tag @s[gamemode=!spectator,gamemode=!creative] add fkfd.loot.check

schedule function fkfd:systems/loot/inventory/loop 2t append
