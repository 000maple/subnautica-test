# id
data modify storage fkfd:tmp item.id set from storage fkfd:tmp item.data.id

# components
execute if data storage fkfd:tmp item.data.components run data modify storage fkfd:tmp item.components set from storage fkfd:tmp item.data.components
execute unless data storage fkfd:tmp item.data.components run data modify storage fkfd:tmp item.components set value {empty:1b}
