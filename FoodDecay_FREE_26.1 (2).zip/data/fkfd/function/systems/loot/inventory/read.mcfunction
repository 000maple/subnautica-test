# read
execute if items entity @s weapon.* #fkfd:food[!minecraft:custom_data~{fkfd:{food:1b}}] run return run function fkfd:systems/loot/inventory/read/weapon
execute if items entity @s hotbar.* #fkfd:food[!minecraft:custom_data~{fkfd:{food:1b}}] run return run function fkfd:systems/loot/inventory/read/hotbar
execute if items entity @s inventory.* #fkfd:food[!minecraft:custom_data~{fkfd:{food:1b}}] run return run function fkfd:systems/loot/inventory/read/inventory
