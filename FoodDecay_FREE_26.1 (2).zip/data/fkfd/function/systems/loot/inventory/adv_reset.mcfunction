advancement revoke @s only fkfd:inv_changed_food
tag @s remove fkfd.loot.check
