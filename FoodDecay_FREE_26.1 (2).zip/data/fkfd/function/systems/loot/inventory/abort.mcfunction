tellraw @a[tag=fkdev] {"storage":"fkfd:text","nbt":"log.loot.process.error","interpret":true}
function fkfd:systems/loot/inventory/adv_reset
