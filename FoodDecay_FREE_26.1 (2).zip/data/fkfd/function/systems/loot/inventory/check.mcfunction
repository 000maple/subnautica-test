# check if vanilla food, or reset
execute store result score #tmp fkfd.options run clear @s #fkfd:food[!minecraft:custom_data~{fkfd:{food:1b}}] 0
execute if score #tmp fkfd.options matches 0 run return run function fkfd:systems/loot/inventory/adv_reset

# canceler
execute if entity @s[tag=fooddecay.immune] run return run function fkfd:systems/loot/inventory/adv_reset
execute if entity @s[tag=fooddecay.loot.immune] run return run function fkfd:systems/loot/inventory/adv_reset

# find item
data remove storage fkfd:tmp item
function fkfd:systems/loot/inventory/read
execute unless data storage fkfd:tmp item run return run function fkfd:systems/loot/inventory/abort
function fkfd:systems/loot/inventory/extract

# process
return run function fkfd:systems/loot/inventory/action/drop with storage fkfd:tmp item
