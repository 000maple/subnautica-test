give @s minecraft:honey_bottle[custom_data={fkfd:{food:1b}},max_stack_size=1,tooltip_display={hidden_components:["damage"]},damage=0,max_damage=10000]
