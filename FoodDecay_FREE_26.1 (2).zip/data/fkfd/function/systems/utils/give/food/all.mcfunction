function fkfd:systems/utils/give/food/very_fast
function fkfd:systems/utils/give/food/fast
function fkfd:systems/utils/give/food/medium
function fkfd:systems/utils/give/food/slow
function fkfd:systems/utils/give/food/very_slow
function fkfd:systems/utils/give/food/imperishable