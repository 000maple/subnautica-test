# FoodDecay
A Minecraft Datapack to add food decay over time. 6 different decay speeds depending of the food category. Eating food effects. Fridge containers.

# Requires 
- Minecraft 26.1+

# Use
1. Download the package
2. Copy/paste the entire "FoodDecay/" folder in your "saves/your-map/datapacks/" folder.
3. Launch the game/server and play your map as you always do.

# Author
- Name: FunkyToc 
- Patreon: https://www.patreon.com/c/funkytoc
- PMC: https://www.planetminecraft.com/member/funkytoc/
- Modrinth: https://modrinth.com/user/FunkyToc

# License
This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License: http://creativecommons.org/licenses/by-nc-nd/4.0/

# Thanks 
My Patreons that buy me coffee every days.
My community wich reminds me that I'm lazy.
Minecraft community in general, that gives meaning to this project.
Life, to be.
