execute unless score #spawn.placed fkdbos.options matches 1 run function fkdbos:schedules/place_spawn
function fkdbos:schedules/mobs
function fkdbos:schedules/structures
function fkdbos:schedules/cleaner
