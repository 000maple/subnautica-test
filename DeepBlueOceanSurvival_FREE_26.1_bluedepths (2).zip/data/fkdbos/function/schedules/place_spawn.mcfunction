# loop
execute if score #spawn.placed fkdbos.options matches 0 run schedule function fkdbos:schedules/place_spawn 1s

# canceler
execute if score #spawn.placed fkdbos.options matches 1 run return 0

# place
execute if loaded ~ ~ ~ if loaded ~ ~-16 ~ if loaded ~ ~-32 ~ run function fkdbos:systems/spawn/rng
