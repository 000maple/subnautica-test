# loop
schedule function fkdbos:schedules/structures 5t

# canceler

execute unless entity @p run return fail

# speed rings
execute at @a[gamemode=!spectator] as @e[type=minecraft:marker,tag=fkdbos.ring,distance=..32] at @s run function fkdbos:systems/structures/speed_ring/check

# totem
execute at @a[gamemode=!spectator] as @e[type=minecraft:marker,tag=fkdbos.totem,distance=..32] at @s run function fkdbos:systems/structures/totem/check
