# loop
schedule function fkdbos:schedules/cleaner 300s

# canceler
execute unless score global.enable fkdbos.options matches 1 run return fail

# update freedive attr
execute as @a run attribute @s minecraft:oxygen_bonus modifier remove fkdbos:freedive

# clear high_contrast effect
execute as @a[predicate=!fkdbos:mask/night_vision_vanilla_effect] unless items entity @s armor.head #minecraft:head_armor[minecraft:custom_data~{fkdbos:{high_contrast:true}}] run function fkdbos:systems/equipment/mask/high_contrast/effect_clear

# clean Blue Depths entities
execute unless score detect.blue_depths fkdbos.options matches 1 run kill @e[tag=bd_mob]

# detect compatibility changes
function fkdbos:compatibility/detect
function fkdbos:compatibility/clean
