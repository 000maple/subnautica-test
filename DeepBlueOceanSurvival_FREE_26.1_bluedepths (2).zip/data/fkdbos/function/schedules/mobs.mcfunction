# loop
schedule function fkdbos:schedules/mobs 5s

# canceler

execute unless entity @p run return fail

# turtle replace squid chance
execute run function fkdbos:systems/mobs/turtle/check

# generic scale for ocean entities
execute run function fkdbos:systems/mobs/scale/check

# remove trident from drowned at spawn
execute run function fkdbos:systems/mobs/drowned/check
