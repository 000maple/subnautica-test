scoreboard objectives remove fkdbos.options

execute as @a run attribute @s minecraft:oxygen_bonus modifier remove fkdbos:freedive

tellraw @s ["",{"storage":"fkdbos:text","nbt":"project.print","interpret":true},{"text":"Uninstalled.","color":"red"},{"text":" Don't forget to ","color":"red"},{"text":"[disable datapack]","bold":true,"color":"aqua","click_event":{"action":"suggest_command","command":"/datapack disable \"file/DeepBlueOceanSurvival"}}]
