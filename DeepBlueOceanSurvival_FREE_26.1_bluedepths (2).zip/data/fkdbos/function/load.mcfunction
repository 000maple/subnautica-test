# project
data modify storage fkdbos:text project.name set value "DeepBlueOceanSurvival"
data modify storage fkdbos:text project.name_short set value "DeepBlue"
data modify storage fkdbos:text project.compatibility set value "26.1+"
data modify storage fkdbos:text project.print set value [{"text":"[","bold":true,"color":"gold","hover_event":{"action":"show_text","value":[{"storage":"fktool:info","nbt":"load.devby","interpret":true}]}},{"storage":"fkdbos:text","nbt":"project.name","interpret":true,"bold":true,"color":"gold"},{"text":"] ","bold":true,"color":"gold","hover_event":{"action":"show_text","value":[{"storage":"fktool:info","nbt":"load.devby","interpret":true}]}}]
data modify storage fkdbos:text project.print_short set value [{"text":"[","bold":true,"color":"gold","hover_event":{"action":"show_text","value":[{"storage":"fktool:info","nbt":"load.devby","interpret":true}]}},{"storage":"fkdbos:text","nbt":"project.name_short","interpret":true,"bold":true,"color":"gold"},{"text":"] ","bold":true,"color":"gold","hover_event":{"action":"show_text","value":[{"storage":"fktool:info","nbt":"load.devby","interpret":true}]}}]

# scores
scoreboard objectives add fkdbos.options dummy {"text":"DeepBlue Options","color":"#008058"}

# constants
scoreboard players set #256 fktool 256

# config
function fkdbos:properties
function fkdbos:schedules/list

# compatibility
schedule function fkdbos:compatibility/detect 20t
schedule function fkdbos:compatibility/checks 40t

# display
tellraw @a ["",{"storage":"fkdbos:text","nbt":"project.print","interpret":true},{"storage":"fktool:info","nbt":"load.enabled","interpret":true},{"text":" ("},{"storage":"fkdbos:text","nbt":"project.compatibility","interpret":true},{"text":"). "},{"storage":"fktool:info","nbt":"load.options","interpret":true},{"text":"[click here]","bold":true,"color":"aqua","click_event":{"action":"suggest_command","command":"/function fkdbos:options/get"}}]
tellraw @a ["",{"storage":"fkdbos:text","nbt":"project.print","interpret":true},{"storage":"fktool:info","nbt":"load.networks","interpret":true}]
tellraw @a ["",{"storage":"fkdbos:text","nbt":"project.print","interpret":true},{"storage":"fktool:info","nbt":"load.free","interpret":true}]
