### DeepBlue Datapack
###
### Developped by FunkyToc
### With love
### And a big amount of time


## config

# Enable/disable all datapack's related systems
# default: 1
# 0: disable
# 1: enable
execute unless score global.enable fkdbos.options matches 0.. run scoreboard players set global.enable fkdbos.options 1

# Sea level indicator
# default: 256
# range: -64 - 386
# info: this variable is a reference for other systems. It do not change the worldgen's sea level.
execute unless score global.sea_lvl fkdbos.options matches 0.. run scoreboard players set global.sea_lvl fkdbos.options 256

# Player base oxygen duration (represented by the HUD bubbles) (seconds)
# default: 30.0
# vanilla: 15.0
# Range: 0.0 - 999.9
# 0: disable (= vanilla)
execute unless data storage fkdbos:var oxygen_total run data modify storage fkdbos:var oxygen_total set value 30.0

# Fix the underwater door exploit to create breathable area
# default: 1
# 0: disable
# 1: enable
execute unless score doorfix.enable fkdbos.options matches 0.. run scoreboard players set doorfix.enable fkdbos.options 1

# Raycast max check iterations (every 0.2 blocks)
# default: 40 (~8 blocks)
# range: 10 - 99
# info: meant to limit the impact of the command on performances
execute unless score doorfix.raycast.max fkdbos.options matches 0.. run scoreboard players set doorfix.raycast.max fkdbos.options 40


## Crossover Detection

# Automaticaly apply custom setting for Ocean Breaths if detected
# default: 1
# 0: disable
# 1: enable
execute unless score compat.ocean_breaths fkdbos.options matches 0.. run scoreboard players set compat.ocean_breaths fkdbos.options 1

# Automaticaly apply custom setting for Blue Depths if detected
# default: 1
# 0: disable
# 1: enable
execute unless score compat.blue_depths fkdbos.options matches 0.. run scoreboard players set compat.blue_depths fkdbos.options 1


## Structures

# Enable the totem structures to give custom effects
# default: 1
# 0: disable
# 1: enable
execute unless score structure.totem fkdbos.options matches 0.. run scoreboard players set structure.totem fkdbos.options 1

# Enable the speed rings to give speed boost effect
# default: 1
# 0: disable
# 1: enable
execute unless score structure.speed_ring fkdbos.options matches 0.. run scoreboard players set structure.speed_ring fkdbos.options 1


## Mobs

# Range of the scale attribute randomly applied to passive ocean entities in ocean biomes (#fkdbos:scale_can_touch) (%)
# default: 50
# range: 0 - 100
# 0: disable (= no additive scale)
execute unless score mob.scale.range fkdbos.options matches 0.. run scoreboard players set mob.scale.range fkdbos.options 50

# [#fkdbos:scale_can_touch] get a chance to become Megalodons, getting a big scale multiplier (#fkdbos:megalodon_can_touch) (%)
# default: 1
# range: 0 - 100
# 0: disable (= no megalodon scale)
execute unless score mob.megalodon.chance fkdbos.options matches 0.. run scoreboard players set mob.megalodon.chance fkdbos.options 1

# Apply an health multiplier to megalodons
# default: 1
# 0: disable (= normal health)
# 1: enable (= more health)
execute unless score mob.megalodon.health fkdbos.options matches 0.. run scoreboard players set mob.megalodon.health fkdbos.options 1

# Turtle spawn chance in ocean biomes, by replacing a few other entities (#fkdbos:turtle_can_replace) (%)
# default: 10
# Range: 0 - 100
# 0: disable (= no turtle)
execute unless score mob.turtle.spawn fkdbos.options matches 0.. run scoreboard players set mob.turtle.spawn fkdbos.options 10

# Allow Drowned modification
# default: 1
# 0: disable
# 1: enable
execute unless score mob.drowned.enable fkdbos.options matches 0.. run scoreboard players set mob.drowned.enable fkdbos.options 1

# Trident replacement with stone spear, from drowned, at spawn (reduce starting difficulty)
# default: 1
# 0: disable
# 1: enable
execute unless score mob.drowned.no_trident_at_spawn fkdbos.options matches 0.. run scoreboard players set mob.drowned.no_trident_at_spawn fkdbos.options 1

# Trident replacement chance with stone spear, from drowned
# default: 80
# Range: 0 - 100
# 0: disable (= vanilla trident amount)
execute unless score mob.drowned.less_trident fkdbos.options matches 0.. run scoreboard players set mob.drowned.less_trident fkdbos.options 80

# Drowned replacement chance with fish (decrease drowned count)
# default: 50
# Range: 0 - 100
# 0: disable (= vanilla drowned amount)
execute unless score mob.drowned.less_mob fkdbos.options matches 0.. run scoreboard players set mob.drowned.less_mob fkdbos.options 50


## Pressure

# Enable/disable Pressure (depths) systems, increasing the gravity in deep waters
# default: 1
# 0: disable
# 1: enable
execute unless score pressure.enable fkdbos.options matches 0.. run scoreboard players set pressure.enable fkdbos.options 1

# Pressure multiplier, increasing with the Y pos
# default: 10
# range: 0 - 99
execute unless score pressure.multiplier fkdbos.options matches 0.. run scoreboard players set pressure.multiplier fkdbos.options 10

# Floating multiplier, increasing buoyancy of the first 20 meters
# default: 4
# range: 0 - 99
execute unless score pressure.floating_multiplier fkdbos.options matches 0.. run scoreboard players set pressure.floating_multiplier fkdbos.options 4

# Buoyancy Mask multiplier, decreasing the pressure of the first 150m (%)
# default: 99
# range: 0 - 100
execute unless score pressure.buoyancy_mask_multiplier fkdbos.options matches 0.. run scoreboard players set pressure.buoyancy_mask_multiplier fkdbos.options 1

# Abyssal Mask multiplier, decreasing the pressure of the depths
# default: 2
# range: 0 - 9
execute unless score pressure.abyssal_mask_multiplier fkdbos.options matches 0.. run scoreboard players set pressure.abyssal_mask_multiplier fkdbos.options 2


## HUD

# Enable/disable HUD
# default: 1
# 0: disable
# 1: enable
execute unless score hud.enable fkdbos.options matches 0.. run scoreboard players set hud.enable fkdbos.options 1

# Enable/disable HUD
# default: 1
# 0: disable
# 1: enable
execute unless score hud.pressure.enable fkdbos.options matches 0.. run scoreboard players set hud.pressure.enable fkdbos.options 1
