# Ocean Breaths
scoreboard players reset detect.ocean_breaths fkdbos.options
scoreboard players reset #loaded fkdbos.options
execute store success score #loaded fkdbos.options run function fkob:properties
execute unless score #loaded fkdbos.options matches 0 run scoreboard players set detect.ocean_breaths fkdbos.options 1

# Blue Depths
scoreboard players reset detect.blue_depths fkdbos.options
scoreboard players reset #loaded fkdbos.options
execute store success score #loaded fkdbos.options run function blue_depths:cleanup/salmon_check
execute unless score #loaded fkdbos.options matches 0 run scoreboard players set detect.blue_depths fkdbos.options 1

# reset
scoreboard players reset #loaded fkdbos.options
