# suggested Blue Depths settings
scoreboard players set compat.blue_depths fkdbos.options 1

return 1
