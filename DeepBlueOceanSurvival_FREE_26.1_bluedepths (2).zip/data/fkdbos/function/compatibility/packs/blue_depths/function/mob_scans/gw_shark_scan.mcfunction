##Curious Great White Spawn
execute if predicate fkdbostool:rng/15 run function blue_depths:spawning/atk_gw_shark_spawn

## Add tag
tag @s add bd_scanned_gw_shark
