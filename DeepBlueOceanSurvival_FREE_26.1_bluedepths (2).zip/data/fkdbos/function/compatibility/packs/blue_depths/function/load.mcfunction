# display
tellraw @a ["",{"storage":"fkdbos:text","nbt":"project.print_short","interpret":true},{"text":"Custom Load -> ","color":"white"},{"text":"Blue Depths v1.1.0","color":"#80aaff"}]

# scoreboards
# Follow range flag (0 = following turned off, 1 = following turned on)
scoreboard objectives add followRangeFlag dummy
# Counter for growth
scoreboard objectives add marineGrowth dummy
# Scoreboard for spawning
scoreboard objectives add bdSpawner dummy
# Bucket scoreboard for fish use
scoreboard objectives add bdBucketUse minecraft.used:minecraft.water_bucket
# Boss flag
scoreboard objectives add bd_bossFlag dummy
# Attack timer
scoreboard objectives add bd_atkCool dummy
# Raycast counter
scoreboard objectives add bd_raycast dummy
# Boss incrementer for scaling multiple players
scoreboard objectives add bd_scaleBoss dummy
# Staff use cooldown scoreboard
scoreboard objectives add bd_staffCooldown dummy
# Ink cloud cooldown
scoreboard objectives add bd_inkCloudCooldown dummy
# Scoreboards for cooldown conversion
scoreboard objectives add bd_scoreDisplay dummy
scoreboard objectives add bd_constant dummy
# Book use scoreboard
scoreboard objectives add bd_bookSpawn dummy

# Set constants for mathematical use:
scoreboard players set #20 bd_constant 20


# loops
schedule function blue_depths:40t 40t
#schedule function blue_depths:30t 30t
schedule function blue_depths:20t 20t
schedule function blue_depths:10t 10t
schedule function blue_depths:5t 5t