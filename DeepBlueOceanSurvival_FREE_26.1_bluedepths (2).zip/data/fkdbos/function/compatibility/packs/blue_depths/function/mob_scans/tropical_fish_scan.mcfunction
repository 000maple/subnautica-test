## Tuna Spawn
execute if predicate fkdbostool:rng/03 unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/catfish_spawn

###### Tag the salmon to prevent rescan ######
## Add tag
tag @s add bd_scanned
