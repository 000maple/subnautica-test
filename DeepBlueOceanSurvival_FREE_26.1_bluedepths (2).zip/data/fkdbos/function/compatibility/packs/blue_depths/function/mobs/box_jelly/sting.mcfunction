effect give @a[distance=..2,sort=nearest,limit=3,gamemode=!creative,gamemode=!spectator] minecraft:poison 4 0
execute as @a[distance=..2,sort=nearest,limit=3,gamemode=!creative,gamemode=!spectator] run damage @s 1 minecraft:sting by @n[type=minecraft:cod,tag=bd_boxJelly,distance=..1]
