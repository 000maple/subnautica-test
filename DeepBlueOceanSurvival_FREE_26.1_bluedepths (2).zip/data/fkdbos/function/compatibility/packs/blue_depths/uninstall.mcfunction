kill @e[tag=bd_mob]

schedule clear blue_depths:5t
schedule clear blue_depths:10t
schedule clear blue_depths:20t
schedule clear blue_depths:40t

scoreboard objectives remove followRangeFlag
scoreboard objectives remove marineGrowth
scoreboard objectives remove bdSpawner
scoreboard objectives remove bdBucketUse
scoreboard objectives remove bd_bossFlag
scoreboard objectives remove bd_atkCool
scoreboard objectives remove bd_raycast
scoreboard objectives remove bd_scaleBoss
scoreboard objectives remove bd_staffCooldown
scoreboard objectives remove bd_inkCloudCooldown
scoreboard objectives remove bd_scoreDisplay
scoreboard objectives remove bd_constant
scoreboard objectives remove bd_bookSpawn
