# reset Blue Depths settings
scoreboard players reset compat.blue_depths fkdbos.options

return 1
