# suggested Ocean Breaths settings
scoreboard players reset Compat.DeepBlue fkob.options
function fkob:options/reset

return 1
