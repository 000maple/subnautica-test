# suggested Ocean Breaths settings
scoreboard players set Compat.DeepBlue fkob.options 1
scoreboard players set Bubble.Enable fkob.options 1
scoreboard players set Bubble.Spawn.Multiplier fkob.options 1
scoreboard players set Bubble.O2 fkob.options 1
scoreboard players set Bubble.MaxO2 fkob.options 1
scoreboard players set Chimney.Enable fkob.options 1
scoreboard players set Chimney.Spawn.Multiplier fkob.options 1
scoreboard players set Chimney.O2 fkob.options 1
scoreboard players set Chimney.MaxO2 fkob.options 1
scoreboard players set Safezone.Enable fkob.options 1
scoreboard players set Safezone.Spawn.Multiplier fkob.options 1
scoreboard players set Safezone.O2 fkob.options 1
scoreboard players set Safezone.MaxO2 fkob.options 1

return 1
