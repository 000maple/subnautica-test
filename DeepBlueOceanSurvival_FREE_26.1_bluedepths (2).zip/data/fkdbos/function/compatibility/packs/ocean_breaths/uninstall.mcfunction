kill @e[type=minecraft:marker,tag=fkob.bubble]

scoreboard objectives remove fkob.options
scoreboard objectives remove fkob.o2
