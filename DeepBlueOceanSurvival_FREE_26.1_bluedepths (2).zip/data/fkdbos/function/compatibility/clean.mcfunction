# Ocean Breaths
execute unless score detect.ocean_breaths fkdbos.options matches 1 if score Bubble.Enable fkob.options matches 0.. run function fkdbos:compatibility/packs/ocean_breaths/uninstall

# Blue Depths
execute unless score detect.blue_depths fkdbos.options matches 1 if score #20 bd_constant matches 0.. run function fkdbos:compatibility/packs/blue_depths/uninstall
