scoreboard players set global.enable fkdbos.options 1
scoreboard players set global.sea_lvl fkdbos.options 256
data modify storage fkdbos:var oxygen_total set value 30.0
scoreboard players set mob.scale.range fkdbos.options 50
scoreboard players set mob.megalodon.chance fkdbos.options 1
scoreboard players set mob.megalodon.health fkdbos.options 1
scoreboard players set mob.turtle.spawn fkdbos.options 10
scoreboard players set pressure.enable fkdbos.options 1
scoreboard players set pressure.multiplier fkdbos.options 10
scoreboard players set pressure.floating_multiplier fkdbos.options 4
scoreboard players set pressure.buoyancy_mask_multiplier fkdbos.options 1
scoreboard players set pressure.abyssal_mask_multiplier fkdbos.options 2

tellraw @s ["",{"storage":"fkdbos:text","nbt":"project.print","interpret":true},{"text":"Options have been reset","color":"red"}]
