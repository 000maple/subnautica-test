advancement revoke @s only fkdbos:system/freedive

# get
execute store result score #tmp1 fkdbos.options run scoreboard players get #300 fktool
execute store success score #tmp2 fkdbos.options run attribute @s minecraft:oxygen_bonus modifier value get fkdbos:freedive 1

# canceler



# remove


# math
scoreboard players operation #multiplier fkdbos.options = #tmp1 fkdbos.options
scoreboard players operation #multiplier fkdbos.options -= #150 fktool
scoreboard players operation #multiplier fkdbos.options /= #15 fktool
execute store result storage fkdbos:var oxygen_multiplier double 0.1 run scoreboard players get #multiplier fkdbos.options

# add

function fkdbos:systems/freedive/update {oxygen_multiplier:2}
