attribute @s minecraft:oxygen_bonus modifier remove fkdbos:freedive
$attribute @s minecraft:oxygen_bonus modifier add fkdbos:freedive $(oxygen_multiplier) add_value
