# place
$execute store success score #spawn.placed fkdbos.options run place template fkdbos:spawn/$(name)

# place spawn entity
kill @e[type=minecraft:marker,tag=fkdbos.spawn]
summon minecraft:marker ~16 ~-32 ~16 {Tags:[fkdbos.spawn]} 
