# rng
execute store result score #tmp fkdbos.options run random value 0..99

# summon
execute if score #tmp fkdbos.options matches 00..30 positioned ~ 256 ~ positioned ~ ~-02 ~ run return run function fkdbos:systems/spawn/summon {name:"raft_1"}
execute if score #tmp fkdbos.options matches 31..60 positioned ~ 256 ~ positioned ~ ~-21 ~ run return run function fkdbos:systems/spawn/summon {name:"observatory"}
execute if score #tmp fkdbos.options matches 61..80 positioned ~ 256 ~ positioned ~ ~-16 ~ run return run function fkdbos:systems/spawn/summon {name:"copper_buoy"}
execute if score #tmp fkdbos.options matches 81..99 positioned ~ 256 ~ positioned ~ ~-13 ~ run return run function fkdbos:systems/spawn/summon {name:"container"}
