# if abyssal mask
execute as @a[tag=fkdbos.mask.abyssal] at @s run function fkdbos:systems/equipment/mask/abyssal/check


execute if entity @p[tag=fkdbos.mask.abyssal] run schedule function fkdbos:systems/equipment/mask/abyssal/loop 5t
