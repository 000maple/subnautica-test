# clear effect
execute unless items entity @s armor.head #minecraft:head_armor[minecraft:custom_data~{fkdbos:{abyssal:true}}] run return run function fkdbos:systems/equipment/mask/abyssal/effect_clear

# in water check
execute anchored eyes positioned ^ ^-0.1 ^ unless predicate fkdbos:in_water/feet run return run attribute @s minecraft:gravity modifier remove fkdbos:abyssal

# only at 21+ bar
function fkdbos:systems/pressure/get
execute if score #tmp.depth fkdbos.options matches ..99 run return run attribute @s minecraft:gravity modifier remove fkdbos:abyssal

# give abyssal
attribute @s minecraft:gravity modifier remove fkdbos:abyssal
execute if score #tmp.depth fkdbos.options matches 100..109 run return run attribute @s minecraft:gravity modifier add fkdbos:abyssal -0.05 add_multiplied_total
execute if score #tmp.depth fkdbos.options matches 110..119 run return run attribute @s minecraft:gravity modifier add fkdbos:abyssal -0.10 add_multiplied_total
execute if score #tmp.depth fkdbos.options matches 120..129 run return run attribute @s minecraft:gravity modifier add fkdbos:abyssal -0.20 add_multiplied_total
execute if score #tmp.depth fkdbos.options matches 130..139 run return run attribute @s minecraft:gravity modifier add fkdbos:abyssal -0.30 add_multiplied_total
execute if score #tmp.depth fkdbos.options matches 140..149 run return run attribute @s minecraft:gravity modifier add fkdbos:abyssal -0.40 add_multiplied_total
execute if score #tmp.depth fkdbos.options matches 000150.. run return run attribute @s minecraft:gravity modifier add fkdbos:abyssal -0.50 add_multiplied_total
