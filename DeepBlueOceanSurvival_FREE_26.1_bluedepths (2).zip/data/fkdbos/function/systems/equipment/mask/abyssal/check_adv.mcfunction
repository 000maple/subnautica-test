advancement revoke @s only fkdbos:system/mask/abyssal

# canceler


# give effect
execute if items entity @s armor.head #minecraft:head_armor[minecraft:custom_data~{fkdbos:{abyssal:true}}] run return run function fkdbos:systems/equipment/mask/abyssal/effect_give

# clear effect
function fkdbos:systems/equipment/mask/abyssal/effect_clear
