tag @s add fkdbos.mask.abyssal
schedule function fkdbos:systems/equipment/mask/abyssal/loop 5t append
