attribute @s minecraft:gravity modifier remove fkdbos:abyssal
tag @s remove fkdbos.mask.abyssal
