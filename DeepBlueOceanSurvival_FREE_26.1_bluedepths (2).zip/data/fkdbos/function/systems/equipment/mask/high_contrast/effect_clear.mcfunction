effect clear @s minecraft:night_vision
tag @s remove fkdbos.mask.high_contrast
