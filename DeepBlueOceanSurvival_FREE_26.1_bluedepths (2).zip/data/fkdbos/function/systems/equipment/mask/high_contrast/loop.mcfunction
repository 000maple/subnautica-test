# clear effect if no high_contrast mask
execute as @a[tag=fkdbos.mask.high_contrast,predicate=!fkdbos:mask/night_vision_vanilla_effect] unless items entity @s armor.head #minecraft:head_armor[minecraft:custom_data~{fkdbos:{high_contrast:true}}] run function fkdbos:systems/equipment/mask/high_contrast/effect_clear


execute if entity @p[tag=fkdbos.mask.high_contrast] run schedule function fkdbos:systems/equipment/mask/high_contrast/loop 20t
