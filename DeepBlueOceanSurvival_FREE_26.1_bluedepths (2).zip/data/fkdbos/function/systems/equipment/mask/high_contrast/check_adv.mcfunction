advancement revoke @s only fkdbos:system/mask/high_contrast

# canceler
execute if predicate fkdbos:mask/night_vision_vanilla_effect run return fail

# give effect
execute if items entity @s armor.head #minecraft:head_armor[minecraft:custom_data~{fkdbos:{high_contrast:true}}] run return run function fkdbos:systems/equipment/mask/high_contrast/effect_give

# clear effect
function fkdbos:systems/equipment/mask/high_contrast/effect_clear
