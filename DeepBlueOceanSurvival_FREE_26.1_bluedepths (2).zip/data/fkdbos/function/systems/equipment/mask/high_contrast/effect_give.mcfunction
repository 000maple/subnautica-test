effect give @s minecraft:night_vision infinite 0 true
tag @s add fkdbos.mask.high_contrast

schedule function fkdbos:systems/equipment/mask/high_contrast/loop 20t append
