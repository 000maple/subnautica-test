tag @s add fkdbos.mask.buoyancy
schedule function fkdbos:systems/equipment/mask/buoyancy/loop 5t append
