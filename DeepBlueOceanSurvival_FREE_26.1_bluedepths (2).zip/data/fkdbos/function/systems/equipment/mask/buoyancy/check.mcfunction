# clear effect
execute unless items entity @s armor.head #minecraft:head_armor[minecraft:custom_data~{fkdbos:{buoyancy:true}}] run return run function fkdbos:systems/equipment/mask/buoyancy/effect_clear

# in water check
execute anchored eyes positioned ^ ^-0.1 ^ unless predicate fkdbos:in_water/feet run return run attribute @s minecraft:gravity modifier remove fkdbos:buoyancy

# only at 1-21 bar
function fkdbos:systems/pressure/get
execute if score #tmp.depth fkdbos.options matches ..005 run return run attribute @s minecraft:gravity modifier remove fkdbos:buoyancy
execute if score #tmp.depth fkdbos.options matches 200.. run return run attribute @s minecraft:gravity modifier remove fkdbos:buoyancy

# give buoyancy
attribute @s minecraft:gravity modifier remove fkdbos:buoyancy
execute if score #tmp.depth fkdbos.options matches 006..149 run return run attribute @s minecraft:gravity modifier add fkdbos:buoyancy -0.99 add_multiplied_total
execute if score #tmp.depth fkdbos.options matches 150..159 run return run attribute @s minecraft:gravity modifier add fkdbos:buoyancy -0.90 add_multiplied_total
execute if score #tmp.depth fkdbos.options matches 160..169 run return run attribute @s minecraft:gravity modifier add fkdbos:buoyancy -0.70 add_multiplied_total
execute if score #tmp.depth fkdbos.options matches 170..179 run return run attribute @s minecraft:gravity modifier add fkdbos:buoyancy -0.50 add_multiplied_total
execute if score #tmp.depth fkdbos.options matches 180..199 run return run attribute @s minecraft:gravity modifier add fkdbos:buoyancy -0.20 add_multiplied_total
