attribute @s minecraft:gravity modifier remove fkdbos:buoyancy
tag @s remove fkdbos.mask.buoyancy
