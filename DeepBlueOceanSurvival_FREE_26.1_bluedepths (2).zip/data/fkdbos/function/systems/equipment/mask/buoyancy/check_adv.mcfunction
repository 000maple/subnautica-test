advancement revoke @s only fkdbos:system/mask/buoyancy

# canceler


# give effect
execute if items entity @s armor.head #minecraft:head_armor[minecraft:custom_data~{fkdbos:{buoyancy:true}}] run return run function fkdbos:systems/equipment/mask/buoyancy/effect_give

# clear effect
function fkdbos:systems/equipment/mask/buoyancy/effect_clear
