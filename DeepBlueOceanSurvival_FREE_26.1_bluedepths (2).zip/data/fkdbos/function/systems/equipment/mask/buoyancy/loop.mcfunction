# if buoyancy mask
execute as @a[tag=fkdbos.mask.buoyancy] at @s run function fkdbos:systems/equipment/mask/buoyancy/check


execute if entity @p[tag=fkdbos.mask.buoyancy] run schedule function fkdbos:systems/equipment/mask/buoyancy/loop 5t
