# in water check
execute anchored eyes positioned ^ ^-0.15 ^ unless predicate fkdbos:in_water/feet run return run function fkdbos:systems/pressure/reset

# above the sea level
execute store result score #tmp fkdbos.options run data get entity @s Pos[1]
execute if score #tmp fkdbos.options > #256 fktool run return run function fkdbos:systems/pressure/reset

# deep in cave, need more water upon head (NOT GOOD)
#scoreboard players operation #tmp.column fkdbos.options = global.sea_lvl fkdbos.options
#scoreboard players remove #tmp.column fkdbos.options 10
#execute if score #tmp fkdbos.options < #tmp.column fkdbos.options anchored eyes positioned ^ ^-0.15 ^ unless block ~ ~2 ~ minecraft:water unless block ~ ~5 ~ minecraft:water run return run function fkdbos:systems/pressure/reset

# apply pressure
function fkdbos:systems/pressure/set
