# get Y pos + eye level
execute store result score #tmp fkdbos.options run data get entity @s Pos[1]
scoreboard players add #tmp fkdbos.options 2

# hud values
scoreboard players operation #tmp.depth fkdbos.options = #256 fktool
scoreboard players operation #tmp.depth fkdbos.options -= #tmp fkdbos.options
scoreboard players operation #tmp.bar.val fkdbos.options = #tmp.depth fkdbos.options
scoreboard players operation #tmp.bar.val fkdbos.options /= #10 fktool
scoreboard players add #tmp.bar.val fkdbos.options 1
scoreboard players operation #tmp.bar.mod fkdbos.options = #tmp.depth fkdbos.options
scoreboard players operation #tmp.bar.mod fkdbos.options %= #10 fktool

# natural buoyancy (0-20m)
scoreboard players add #tmp fkdbos.options 20

# get sea level
scoreboard players operation #tmp fkdbos.options -= #256 fktool

# multiplier
scoreboard players operation #tmp fkdbos.options *= #-1 fktool
scoreboard players operation #tmp fkdbos.options *= #10 fktool
scoreboard players operation #tmp fkdbos.options /= #10 fktool

# floating multiplier (0-20m)
execute if score #tmp fkdbos.options matches ..-1 run scoreboard players operation #tmp fkdbos.options *= #4 fktool

# set storage
execute store result storage fkdbos:tmp hud.attr double 0.04 run scoreboard players get #tmp fkdbos.options
execute store result storage fkdbos:tmp hud.depth int 1 run scoreboard players get #tmp.depth fkdbos.options
execute store result storage fkdbos:tmp hud.bar_val int 1 run scoreboard players get #tmp.bar.val fkdbos.options
execute store result storage fkdbos:tmp hud.bar_mod int 1 run scoreboard players get #tmp.bar.mod fkdbos.options

# return depth
return run scoreboard players get #tmp.depth fkdbos.options
