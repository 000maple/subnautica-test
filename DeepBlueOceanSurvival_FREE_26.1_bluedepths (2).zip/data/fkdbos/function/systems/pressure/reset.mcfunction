tag @s remove fkdbos.water_pressure
attribute @s minecraft:gravity modifier remove fkdbos:water_pressure
