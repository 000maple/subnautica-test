# reset
attribute @s minecraft:gravity modifier remove fkdbos:water_pressure

# set pressure
$attribute @s minecraft:gravity modifier add fkdbos:water_pressure $(attr) add_multiplied_base
