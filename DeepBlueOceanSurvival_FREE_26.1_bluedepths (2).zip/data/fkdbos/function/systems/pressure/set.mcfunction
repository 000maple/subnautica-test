# get pressure
function fkdbos:systems/pressure/get
# apply
execute run function fkdbos:systems/pressure/apply with storage fkdbos:tmp hud

# bar damage
# todo

# hud
execute run function fkdbos:systems/hud/display with storage fkdbos:tmp hud

# challenges
execute unless entity @s[advancements={fkdbos:toast/challenge/depth/300=true}] run function fkdbos:systems/achievements/depths

# reset
data remove storage fkdbos:tmp hud
