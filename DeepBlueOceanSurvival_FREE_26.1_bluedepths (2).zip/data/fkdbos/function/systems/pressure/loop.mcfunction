# if no abyssal mask
execute as @a[tag=fkdbos.water_pressure] at @s run function fkdbos:systems/pressure/check


execute if entity @p[tag=fkdbos.water_pressure] run schedule function fkdbos:systems/pressure/loop 5t
