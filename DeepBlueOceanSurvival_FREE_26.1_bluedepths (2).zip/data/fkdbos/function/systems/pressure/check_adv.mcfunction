advancement revoke @s only fkdbos:system/water_pressure

# give effect
tag @s add fkdbos.water_pressure
schedule function fkdbos:systems/pressure/loop 5t append
