setblock ~ ~ ~ minecraft:water destroy
setblock ~ ~1 ~ minecraft:water destroy
particle minecraft:bubble ~ ~.5 ~ .3 .8 .3 0 30
