# check
execute if block ~ ~ ~ #minecraft:doors[half=lower] align xyz positioned ~.5 ~0.5 ~.5 run return run function fkdbos:systems/doorfix/raycast/found
execute if block ~ ~ ~ #minecraft:doors[half=upper] align xyz positioned ~.5 ~-.5 ~.5 run return run function fkdbos:systems/doorfix/raycast/found

# i++
scoreboard players add #tmp.steps fkdbos.options 1
#particle minecraft:wax_off

# cast
execute if score #tmp.steps fkdbos.options < #40 fktool positioned ^ ^ ^.2 run function fkdbos:systems/doorfix/raycast/cast
