# checks, from door's lower part
execute if block ~ ~02 ~ minecraft:water run return run function fkdbos:systems/doorfix/destroy
execute if block ~01 ~ ~ minecraft:water run return run function fkdbos:systems/doorfix/destroy
execute if block ~-1 ~ ~ minecraft:water run return run function fkdbos:systems/doorfix/destroy
execute if block ~ ~ ~01 minecraft:water run return run function fkdbos:systems/doorfix/destroy
execute if block ~ ~ ~-1 minecraft:water run return run function fkdbos:systems/doorfix/destroy
execute if block ~01 ~ ~ minecraft:water run return run function fkdbos:systems/doorfix/destroy
execute if block ~-1 ~1 ~ minecraft:water run return run function fkdbos:systems/doorfix/destroy
execute if block ~ ~1 ~01 minecraft:water run return run function fkdbos:systems/doorfix/destroy
execute if block ~ ~1 ~-1 minecraft:water run return run function fkdbos:systems/doorfix/destroy

# door is allowed to live
