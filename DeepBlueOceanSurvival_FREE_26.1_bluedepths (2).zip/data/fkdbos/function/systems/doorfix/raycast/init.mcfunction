# init
scoreboard players set #tmp.steps fkdbos.options 0

function fkdbos:systems/doorfix/raycast/cast
