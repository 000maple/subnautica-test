# resets
advancement revoke @s only fkdbos:system/place_door_fix

# find door
execute anchored eyes positioned ^ ^.1 ^.3 run function fkdbos:systems/doorfix/raycast/init
