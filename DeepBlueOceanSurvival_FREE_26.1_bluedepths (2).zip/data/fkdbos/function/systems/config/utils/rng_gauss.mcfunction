# parameters
scoreboard players set #mean fkdbos.options 0

scoreboard players set #total fkdbos.options 0
$execute store result score #tmp fkdbos.options run random value $(min)..$(max)
scoreboard players operation #total fkdbos.options += #tmp fkdbos.options
$execute store result score #tmp fkdbos.options run random value $(min)..$(max)
scoreboard players operation #total fkdbos.options += #tmp fkdbos.options
$execute store result score #tmp fkdbos.options run random value $(min)..$(max)
scoreboard players operation #total fkdbos.options += #tmp fkdbos.options
scoreboard players operation #total fkdbos.options /= #3 fktool
scoreboard players operation #mean fkdbos.options += #total fkdbos.options

scoreboard players set #total fkdbos.options 0
$execute store result score #tmp fkdbos.options run random value $(min)..$(max)
scoreboard players operation #total fkdbos.options += #tmp fkdbos.options
$execute store result score #tmp fkdbos.options run random value $(min)..$(max)
scoreboard players operation #total fkdbos.options += #tmp fkdbos.options
$execute store result score #tmp fkdbos.options run random value $(min)..$(max)
scoreboard players operation #total fkdbos.options += #tmp fkdbos.options
scoreboard players operation #total fkdbos.options /= #3 fktool
scoreboard players operation #mean fkdbos.options += #total fkdbos.options

# mean
scoreboard players operation #mean fkdbos.options /= #2 fktool

# result
execute store result score #rng fkdbos.options run return run scoreboard players get #mean fkdbos.options
