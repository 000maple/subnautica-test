# depths challenges
execute if score #tmp.depth fkdbos.options matches 010.. run advancement grant @s only fkdbos:toast/challenge/main
execute if score #tmp.depth fkdbos.options matches 025.. run advancement grant @s only fkdbos:toast/challenge/depth/025
execute if score #tmp.depth fkdbos.options matches 050.. run advancement grant @s only fkdbos:toast/challenge/depth/050
execute if score #tmp.depth fkdbos.options matches 100.. run advancement grant @s only fkdbos:toast/challenge/depth/100
execute if score #tmp.depth fkdbos.options matches 150.. run advancement grant @s only fkdbos:toast/challenge/depth/150
execute if score #tmp.depth fkdbos.options matches 200.. run advancement grant @s only fkdbos:toast/challenge/depth/200
execute if score #tmp.depth fkdbos.options matches 250.. run advancement grant @s only fkdbos:toast/challenge/depth/250
execute if score #tmp.depth fkdbos.options matches 300.. run advancement grant @s only fkdbos:toast/challenge/depth/300
