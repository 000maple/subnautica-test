# canceler
execute unless predicate fkdbos:in_water/feet run return fail

# effect
effect give @a[distance=..2] minecraft:dolphins_grace 15 0 false

# fx
particle minecraft:current_down ~ ~2.5 ~-.5 0 0 0 0 1
particle minecraft:current_down ~ ~1.5 ~-.5 0 0 0 0 1
particle minecraft:current_down ~ ~0.5 ~-.5 0 0 0 0 1
particle minecraft:current_down ~ ~-.5 ~-.5 0 0 0 0 1
particle minecraft:bubble_column_up ~ ~-2.5 ~ .2 .2 .2 0 1
execute if predicate fkdbostool:rng/10 run playsound minecraft:block.water.ambient player @a[distance=..6] ~ ~ ~ 1.2 .5 1
