# canceler
execute positioned ~ ~5 ~ unless predicate fkdbos:in_water/feet run return fail
execute unless block ~ ~ ~ #fkdbos:copper_bulbs[lit=true] run return fail

# effect
effect give @a[distance=..8,gamemode=!spectator] minecraft:strength 5 0 false

# fx
particle minecraft:ash ~ ~ ~ 4 2 4 0 5
particle minecraft:bubble_column_up ~ ~-3 ~ 1.5 1 1.5 0 3
execute if predicate fkdbostool:rng/001 run playsound minecraft:ambient.underwater.loop.additions.ultra_rare player @a[distance=..8] ~ ~ ~ 5 2 1
