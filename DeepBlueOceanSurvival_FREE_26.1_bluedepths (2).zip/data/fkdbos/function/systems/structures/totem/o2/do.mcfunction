# canceler
execute unless predicate fkdbos:in_water/feet run return fail

# disable
execute unless block ~ ~-5 ~ #fkdbos:copper_bulbs[lit=true] run return run tag @s remove fkob.safezone

# enable
execute if entity @s[tag=!fkob.safezone] run return run tag @s add fkob.safezone
