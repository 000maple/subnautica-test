# o2
execute if entity @s[tag=fkdbos.totem.o2] run return run function fkdbos:systems/structures/totem/o2/do

# war
execute if entity @s[tag=fkdbos.totem.war] run return run function fkdbos:systems/structures/totem/war/do

# nope
return fail
