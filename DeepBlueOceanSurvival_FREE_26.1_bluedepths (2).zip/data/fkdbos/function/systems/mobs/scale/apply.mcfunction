$attribute @s minecraft:scale modifier add $(scale_id) $(scale_multiplier) add_multiplied_base
