# megalodon chance
execute if entity @s[type=#fkdbos:megalodon_can_touch] run function fkdbos:systems/mobs/scale/megalodon

# rng
execute store result score #rng fkdbos.options run function fkdbos:systems/config/utils/rng_gauss {min:-200,max:200}
execute if score #rng fkdbos.options matches 0 run return run tag @s add fkdbos.scale

# get scale
scoreboard players operation #tmp.scale fkdbos.options = #50 fktool
scoreboard players operation #tmp.scale fkdbos.options *= #rng fkdbos.options
execute store result storage fkdbos:var scale_multiplier double 0.0001 run scoreboard players get #tmp.scale fkdbos.options
data modify storage fkdbos:var scale_id set value "fkdbos:scale"

# apply
function fkdbos:systems/mobs/scale/apply with storage fkdbos:var
tag @s add fkdbos.scale
