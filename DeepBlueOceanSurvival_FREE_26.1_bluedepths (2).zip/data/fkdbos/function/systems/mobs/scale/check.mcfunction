# random replace squid into turtle
execute at @a as @e[type=#fkdbos:scale_can_touch,tag=!fkdbos.scale,tag=!global.ignore,distance=16..128,sort=nearest,limit=16] at @s if biome ~ ~ ~ #fkdbos:is_ocean run function fkdbos:systems/mobs/scale/touch
