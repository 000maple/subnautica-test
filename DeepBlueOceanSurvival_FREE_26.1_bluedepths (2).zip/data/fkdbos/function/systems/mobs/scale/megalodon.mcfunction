# rng
execute store result score #rng fkdbos.options run random value 1..100
execute unless score #rng fkdbos.options <= #1 fktool run return fail

# get scale
execute store result score #rng fkdbos.options run random value 1..100
execute if score #rng fkdbos.options matches 01..015 run data modify storage fkdbos:var scale_multiplier set value 3.0
execute if score #rng fkdbos.options matches 16..050 run data modify storage fkdbos:var scale_multiplier set value 2.5
execute if score #rng fkdbos.options matches 51..100 run data modify storage fkdbos:var scale_multiplier set value 2.0
data modify storage fkdbos:var scale_id set value "fkdbos:megalodon"
function fkdbos:systems/mobs/scale/apply with storage fkdbos:var

# more hp
execute if score #rng fkdbos.options matches 01..015 run attribute @s minecraft:max_health modifier add fkdbos:health 2.0 add_multiplied_base
execute if score #rng fkdbos.options matches 16..050 run attribute @s minecraft:max_health modifier add fkdbos:health 1.0 add_multiplied_base
execute if score #rng fkdbos.options matches 51..100 run attribute @s minecraft:max_health modifier add fkdbos:health 0.5 add_multiplied_base

# regen hp
execute store result storage fkdbos:var health int 1 run attribute @s minecraft:max_health get
data modify entity @s Health set from storage fkdbos:var health

# tag
tag @s add fkdbos.megalodon
