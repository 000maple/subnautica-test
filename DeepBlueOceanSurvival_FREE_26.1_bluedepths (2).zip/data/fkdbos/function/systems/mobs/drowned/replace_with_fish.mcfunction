# replace drowned with fish (chance)
execute store result score #rng fkdbos.options run random value 1..100

# canceler
execute unless score mob.drowned.less_mob fkdbos.options >= #rng fkdbos.options run return fail

# replace
execute if score detect.blue_depths fkdbos.options matches 1 run function blue_depths:summon/catfish
execute unless score detect.blue_depths fkdbos.options matches 1 run summon minecraft:pufferfish ~ ~ ~ {Tags:[fkdbos.entity,fkdbos.touched],Health:20f,attributes:[{id:"minecraft:max_health",base:20},{id:"minecraft:scale",base:2.0}]}
tp @s ~ ~-500 ~
kill @s
