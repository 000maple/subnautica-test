# replace trident with spear
execute if items entity @s weapon.mainhand minecraft:trident run item replace entity @s weapon.mainhand with minecraft:stone_spear
