# replace trident with spear (chance)
execute store result score #rng fkdbos.options run random value 1..100

# canceler
execute unless score mob.drowned.less_trident fkdbos.options >= #rng fkdbos.options run return fail

# replace
item replace entity @s weapon.mainhand with minecraft:stone_spear
