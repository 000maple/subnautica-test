# touch drowned
execute at @a as @e[type=minecraft:drowned,tag=!fkdbos.touched,tag=!global.ignore,distance=32..96,sort=nearest,limit=4] at @s run function fkdbos:systems/mobs/drowned/touch
