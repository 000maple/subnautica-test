execute if items entity @s weapon.mainhand minecraft:trident if entity @n[type=minecraft:marker,tag=fkdbos.spawn,distance=..256] run function fkdbos:systems/mobs/drowned/trident/replace
execute if items entity @s weapon.mainhand minecraft:trident run function fkdbos:systems/mobs/drowned/trident/replace_chance
execute run function fkdbos:systems/mobs/drowned/replace_with_fish

tag @s add fkdbos.touched
