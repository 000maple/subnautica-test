# summon
summon minecraft:turtle ~ ~ ~ {Tags:[fkdbos.entity]}

# kill
tp @s ~ ~-500 ~
kill @s
