# rng
execute store result score #rng fkdbos.options run random value 1..100

# canceler
execute unless score mob.turtle.spawn fkdbos.options >= #rng fkdbos.options run return run tag @s add fkdbos.ignore

# replace
function fkdbos:systems/mobs/turtle/replace
