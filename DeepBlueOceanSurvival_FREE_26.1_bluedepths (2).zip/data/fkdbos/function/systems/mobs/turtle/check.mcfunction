# random replace squid into turtle
execute at @a as @e[type=#fkdbos:turtle_can_replace,tag=!fkdbos.ignore,tag=!global.ignore,distance=32..96,sort=nearest,limit=4] at @s if biome ~ ~ ~ #fkdbos:is_ocean run function fkdbos:systems/mobs/turtle/touch
