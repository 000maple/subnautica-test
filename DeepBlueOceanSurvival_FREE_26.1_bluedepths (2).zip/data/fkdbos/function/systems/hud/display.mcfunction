# canceler
execute unless items entity @s armor.head #minecraft:head_armor[minecraft:custom_data~{fkdbos:{diving_mask:true}}] run return fail

# depth
data modify storage fkdbos:tmp hud.depth_color set value "white"

# bar
execute if score #tmp.bar.val fkdbos.options matches 01..04 run data modify storage fkdbos:tmp hud.bar_color set value "white"
execute if score #tmp.bar.val fkdbos.options matches 05..11 run data modify storage fkdbos:tmp hud.bar_color set value "#fff370"
execute if score #tmp.bar.val fkdbos.options matches 12..19 run data modify storage fkdbos:tmp hud.bar_color set value "#fea062"
execute if score #tmp.bar.val fkdbos.options matches 20..24 run data modify storage fkdbos:tmp hud.bar_color set value "#ff7e47"
execute if score #tmp.bar.val fkdbos.options matches 25..29 run data modify storage fkdbos:tmp hud.bar_color set value "#fe5c34"
execute if score #tmp.bar.val fkdbos.options matches 30.. run data modify storage fkdbos:tmp hud.bar_color set value "#ff270f"

# bar warning (with Pa armor resistance & Pa damage)
data modify storage fkdbos:tmp hud.bar_warning set value ""
execute if score #tmp.bar.val fkdbos.options matches 30.. run data modify storage fkdbos:tmp hud.bar_warning set value "\u26a0"
data modify storage fkdbos:tmp hud.bar_warning_color set value "#ff270f"

# O²
#execute if score #tmp.o2 fkdbos.options matches 1..5 run data modify storage fkdbos:tmp hud.depth_color set value "white"
#execute if score #tmp.o2 fkdbos.options matches 6.. run data modify storage fkdbos:tmp hud.depth_color set value "white"

# print
function fkdbos:systems/hud/print with storage fkdbos:tmp hud
