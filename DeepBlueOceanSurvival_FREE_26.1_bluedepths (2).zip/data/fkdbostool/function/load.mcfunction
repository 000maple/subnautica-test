# scores
scoreboard objectives add fktool dummy

# init
function fkdbostool:utils/set_constants
function fkdbostool:utils/tellraw
function fkdbostool:rng/get
function fkdbostool:warnings/get
