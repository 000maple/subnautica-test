# DBOS handle pack?
execute run return run schedule function fkdbos:compatibility/packs/blue_depths/function/load 41t

# display
tellraw @a [{"color":"#1E90FF","text":"-- Blue Depths v1.1.0 successfully loaded! --"},{"color":"white","text":"\n• New sea creatures now roam the oceans and rivers..."},{"color":"dark_green","text":"\n• Welcome to Roaring Rivers Part 1: \"Below the Surface\"!"},{"color":"green","text":"\n• New content for v1.1.0: Bull Sharks, Archerfish, and Bass!"},{"color":"red","text":"\n• Use your guide book to uncover and summon a beast lost to time"}]

# scoreboards
# Follow range flag (0 = following turned off, 1 = following turned on)
scoreboard objectives add followRangeFlag dummy
# Counter for growth
scoreboard objectives add marineGrowth dummy
# Scoreboard for spawning
scoreboard objectives add bdSpawner dummy
# Bucket scoreboard for fish use
scoreboard objectives add bdBucketUse minecraft.used:minecraft.water_bucket
# Boss flag
scoreboard objectives add bd_bossFlag dummy
# Attack timer
scoreboard objectives add bd_atkCool dummy
# Raycast counter
scoreboard objectives add bd_raycast dummy
# Boss incrementer for scaling multiple players
scoreboard objectives add bd_scaleBoss dummy
# Staff use cooldown scoreboard
scoreboard objectives add bd_staffCooldown dummy
# Ink cloud cooldown
scoreboard objectives add bd_inkCloudCooldown dummy
# Scoreboards for cooldown conversion
scoreboard objectives add bd_scoreDisplay dummy
scoreboard objectives add bd_constant dummy
# Book use scoreboard
scoreboard objectives add bd_bookSpawn dummy

# Set constants for mathematical use:
scoreboard players set #20 bd_constant 20


# loops
schedule function blue_depths:40t 40t
#schedule function blue_depths:30t 30t
schedule function blue_depths:20t 20t
schedule function blue_depths:10t 10t
schedule function blue_depths:5t 5t
