# DBOS handle pack?
execute run return run function fkdbos:compatibility/packs/blue_depths/function/mob_scans/salmon_scans/river

##### Spawn river creatures

## Largemouth Bass Spawn
execute if predicate blue_depths:20_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/river/lm_bass_spawn

## Catfish Spawn
execute if predicate blue_depths:15_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/river/catfish/catfish_master

## Spawn Bull Shark
execute if predicate blue_depths:8_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/river/bull_shark/bull_shark_master

## Archerfish Spawn
execute if predicate blue_depths:4_1_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/river/archerfish_spawn

## Sturgeon Spawn
execute if predicate blue_depths:4_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/sturgeon_spawn
