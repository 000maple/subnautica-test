# DBOS handle pack?
execute run return run function fkdbos:compatibility/packs/blue_depths/function/mob_scans/salmon_scans/ocean

## Orca Spawn Frozen Ocean
###### Spawn custom mobs (ocean)

## Orca Spawn Frozen Ocean
execute if predicate blue_depths:1_percent_chance if biome ~ ~ ~ minecraft:frozen_ocean unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/orca_spawn
## Orca Spawn for Deep Frozen Ocean
execute if predicate blue_depths:1_percent_chance if biome ~ ~ ~ minecraft:deep_frozen_ocean unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/orca_spawn
