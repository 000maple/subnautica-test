# DBOS handle pack?
execute run return run function fkdbos:compatibility/packs/blue_depths/function/mob_scans/tropical_fish_scan

## Tuna Spawn
execute if predicate blue_depths:20_percent_chance if biome ~ ~ ~ minecraft:mangrove_swamp unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/catfish_spawn

###### Tag the salmon to prevent rescan ######
## Add tag
tag @s add bd_scanned
