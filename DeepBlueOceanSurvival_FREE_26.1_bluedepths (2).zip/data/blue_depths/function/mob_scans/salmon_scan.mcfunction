# DBOS handle pack?
execute run return run function fkdbos:compatibility/packs/blue_depths/function/mob_scans/salmon_scan

####Execute as and at eligible salmon

## River mobs spawn
execute if biome ~ ~ ~ minecraft:river run function blue_depths:mob_scans/salmon_scans/river
## Ocean mobs spawn
execute unless biome ~ ~ ~ minecraft:river run function blue_depths:mob_scans/salmon_scans/ocean

###### Tag the salmon to prevent rescan ######
## Add tag
tag @s add bd_scanned
