# DBOS handle pack?
execute run return run function fkdbos:compatibility/packs/blue_depths/function/mobs/box_jelly/sting

effect give @a[sort=nearest,limit=1,gamemode=!creative,gamemode=!spectator] slowness 3 2
effect give @a[sort=nearest,limit=1,gamemode=!creative,gamemode=!spectator] weakness 6 1
effect give @a[sort=nearest,limit=1,gamemode=!creative,gamemode=!spectator] mining_fatigue 6
damage @a[sort=nearest,limit=1,gamemode=!creative,gamemode=!spectator] 3 minecraft:sting
