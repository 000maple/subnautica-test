# DeepBlueOceanSurvival
A Minecraft worldgen datapack to submerged the overworld with endless oceans. The depths stand between 50 and 300 blocks. Player's oxygen is set to 45 seconds.

# Requires
- Minecraft 26.1+

# Use
1. Download the package and unzip it
2. Copy/paste the entire "DeepBlueOceanSurvival/" folder in your "saves/your-map/datapacks/" folder.
3. Launch the game/server and play your map as you always do.

# Author
- Name: FunkyToc 
- PMC: https://www.planetminecraft.com/member/funkytoc/
- Modrinth: https://modrinth.com/user/FunkyToc
- Patreon: https://www.patreon.com/c/funkytoc

# License
This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License: http://creativecommons.org/licenses/by-nc-nd/4.0/

# Thanks
My Patreons that buy me coffee every days.
My community wich reminds me that I'm lazy.
Minecraft community, that gives meaning to this project.
Life, to be.
