# scores
scoreboard objectives add fktool dummy

# init
function fkobtool:utils/set_constants
function fkobtool:utils/tellraw
function fkobtool:rng/get
function fkobtool:warnings/get
