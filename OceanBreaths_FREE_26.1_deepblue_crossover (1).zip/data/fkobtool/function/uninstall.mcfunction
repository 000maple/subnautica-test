scoreboard objectives remove fktool
