# reset
tag @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.active] remove safezone.active
tag @e[type=minecraft:marker,tag=fkob.oxidizer,tag=oxidizer.active] remove oxidizer.active

# main
execute as @a at @s if predicate fkob:in_water/feet align y run function fkob:tick_compat

# loop
schedule function fkob:tick 5s
