execute if score Compat_Vanilla fkob.options matches 1 if predicate fkob:compatibility/vanilla_oceans run return run function fkob:loop
execute if score Compat_Terralith fkob.options matches 1 if predicate fkob:compatibility/terralith_oceans run return run function fkob:loop
