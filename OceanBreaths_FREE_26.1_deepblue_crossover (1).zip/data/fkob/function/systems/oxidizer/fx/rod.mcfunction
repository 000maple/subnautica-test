# get power
execute store result score #tmp fkob.options run function fkob:systems/oxidizer/state/power


## fx

# bubble
execute if score #tmp fkob.options matches 1..2 run particle minecraft:bubble ~ ~ ~ .02 .30 .02 .05 4
execute if score #tmp fkob.options matches 3..4 run particle minecraft:bubble ~ ~ ~ .02 .30 .02 .05 8
execute if score #tmp fkob.options matches 05.. run particle minecraft:bubble ~ ~ ~ .02 .30 .02 .05 12

# fishing
execute if score #tmp fkob.options matches 1..2 run particle minecraft:fishing ~ ~ ~ .02 .30 .02 .05 2
execute if score #tmp fkob.options matches 3..4 run particle minecraft:fishing ~ ~ ~ .02 .30 .02 .05 5
execute if score #tmp fkob.options matches 05.. run particle minecraft:fishing ~ ~ ~ .02 .30 .02 .05 8

# electricity
execute if score #tmp fkob.options matches 1..2 if predicate fkobtool:rng/05 run particle minecraft:electric_spark ~ ~ ~ .05 .25 .05 .05 5
execute if score #tmp fkob.options matches 3..4 if predicate fkobtool:rng/10 run particle minecraft:electric_spark ~ ~ ~ .05 .25 .05 .05 5
execute if score #tmp fkob.options matches 05.. if predicate fkobtool:rng/20 run particle minecraft:electric_spark ~ ~ ~ .05 .25 .05 .05 5


# sound
execute if predicate fkobtool:rng/30 run playsound minecraft:block.beacon.ambient ambient @a[distance=..16] ~ ~ ~ .5 2
