# active
tag @e[type=minecraft:marker,tag=fkob.oxidizer,distance=..64] add oxidizer.active

# loop
execute if entity @n[type=minecraft:marker,tag=fkob.oxidizer,tag=oxidizer.active] run schedule function fkob:systems/oxidizer/loop 61t append
