# canceler

execute unless entity @n[type=minecraft:marker,tag=fkob.oxidizer,tag=oxidizer.active] run return 0

# fx
execute as @e[type=minecraft:marker,tag=fkob.oxidizer,tag=oxidizer.active,tag=!oxidizer.nofx] at @s run function fkob:systems/oxidizer/fx/rod

# loop
schedule function fkob:systems/oxidizer/loop_fx 10t replace
