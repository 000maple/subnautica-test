tag @s add oxidizer.nofx
tag @s remove fkob.safezone
tag @s remove fkob.safezone.active
