tag @s remove oxidizer.nofx
tag @s add fkob.safezone
tag @s add fkob.safezone.active
