# reset
tag @s remove safezone.tiny
tag @s remove safezone.small
tag @s remove safezone.medium
tag @s remove safezone.large
tag @s remove safezone.massive

# set size
execute if score #tmp fkob.options matches 1 run tag @s add safezone.tiny
execute if score #tmp fkob.options matches 2 run tag @s add safezone.small
execute if score #tmp fkob.options matches 3 run tag @s add safezone.medium
execute if score #tmp fkob.options matches 4 run tag @s add safezone.large
execute if score #tmp fkob.options matches 5 run tag @s add safezone.massive

# apply
function fkob:systems/oxidizer/safezone/update
