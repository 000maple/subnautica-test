# check state
execute unless function fkob:systems/oxidizer/state/structure run return run function fkob:systems/oxidizer/safezone/kill
execute unless function fkob:systems/oxidizer/state/fuel run return run function fkob:systems/oxidizer/safezone/disable

# get power
execute store result score #tmp fkob.options run function fkob:systems/oxidizer/state/power
execute if score #tmp fkob.options matches 0 run return run function fkob:systems/oxidizer/safezone/disable

# update power
function fkob:systems/oxidizer/safezone/power
function fkob:systems/oxidizer/safezone/enable

# start loop
schedule function fkob:systems/safezone/loop 61t append
