# init
scoreboard players set #tmp fkob.o2 40

# start
function fkob:systems/oxidizer/raycast/cast
