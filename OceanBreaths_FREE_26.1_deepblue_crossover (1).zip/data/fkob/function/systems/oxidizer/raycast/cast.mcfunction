# check
execute if block ~ ~ ~ #fkob:oxidizer/fuel align xyz positioned ~.5 ~.5 ~.5 run return run function fkob:systems/oxidizer/raycast/check

# i--
scoreboard players remove #tmp fkob.o2 1

# cast
execute if score #tmp fkob.o2 > #0 fktool positioned ^ ^ ^.1 run return run function fkob:systems/oxidizer/raycast/cast

# reset
scoreboard players reset #tmp fkob.o2
