# reset
scoreboard players reset #tmp fkob.o2

# check oxidizer structure
execute if function fkob:systems/oxidizer/state/structure run function fkob:systems/oxidizer/summon/spawn
