# set fuel power: from 1 (min) to 5 (max)
execute if block ~ ~ ~ minecraft:copper_bars run return 5
execute if block ~ ~ ~ minecraft:exposed_copper_bars run return 4
execute if block ~ ~ ~ minecraft:weathered_copper_bars run return 3
execute if block ~ ~ ~ minecraft:oxidized_copper_bars run return 2

execute if block ~ ~ ~ minecraft:copper_chain run return 5
execute if block ~ ~ ~ minecraft:exposed_copper_chain run return 4
execute if block ~ ~ ~ minecraft:weathered_copper_chain run return 3
execute if block ~ ~ ~ minecraft:oxidized_copper_chain run return 2

# not found
return 0
