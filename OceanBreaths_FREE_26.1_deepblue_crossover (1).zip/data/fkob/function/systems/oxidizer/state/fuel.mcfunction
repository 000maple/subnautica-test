# check fuel
execute unless block ~ ~ ~ #fkob:oxidizer/fuel run return 0

return 1
