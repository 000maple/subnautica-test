# check oxidizer structure
execute unless block ~ ~01 ~ #fkob:oxidizer/rod run return 0
execute unless block ~ ~-1 ~ #fkob:oxidizer/rod run return 0
execute unless block ~ ~02 ~ #fkob:oxidizer/base run return 0
execute unless block ~ ~-2 ~ #fkob:oxidizer/base run return 0
execute unless block ~ ~03 ~ #fkob:oxidizer/energy run return 0
execute unless block ~ ~-3 ~ #fkob:oxidizer/energy run return 0

return 1
