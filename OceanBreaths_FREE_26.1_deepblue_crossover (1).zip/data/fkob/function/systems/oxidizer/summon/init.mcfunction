execute unless predicate fkob:in_water/feet run kill @s
tag @s remove fkob.oxidizer.init
