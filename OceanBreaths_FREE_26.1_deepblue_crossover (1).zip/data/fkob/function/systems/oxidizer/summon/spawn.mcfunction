# fx
playsound minecraft:block.beacon.activate ambient @a[distance=..16] ~ ~ ~ 3 .5
particle minecraft:electric_spark ~ ~ ~ .05 .30 .05 .05 10

# canceler
execute if entity @n[type=minecraft:marker,tag=fkob.oxidizer,distance=..16] run return 0

# summon
summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.oxidizer","fkob.oxidizer.init"]}

# init
execute as @n[type=minecraft:marker,tag=fkob.oxidizer.init,distance=..1] at @s run function fkob:systems/oxidizer/summon/init

# start loop
schedule function fkob:systems/oxidizer/loop 21t append
schedule function fkob:systems/oxidizer/loop_fx 11t append
