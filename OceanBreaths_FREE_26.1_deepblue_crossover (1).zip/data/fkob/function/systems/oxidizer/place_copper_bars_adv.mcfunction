advancement revoke @s only fkob:place_copper_bars

# raycast: find copper bars
execute anchored eyes positioned ^ ^ ^.5 run function fkob:systems/oxidizer/raycast/init
