# canceler
execute unless entity @n[type=minecraft:marker,tag=fkob.oxidizer,tag=oxidizer.active] run return 0

# check state
execute as @e[type=minecraft:marker,tag=fkob.oxidizer,tag=oxidizer.active] at @s run function fkob:systems/oxidizer/safezone/check

# loop
schedule function fkob:systems/oxidizer/loop 60t replace
schedule function fkob:systems/oxidizer/loop_fx 11t append
