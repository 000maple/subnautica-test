execute if predicate fkob:ocean_ground run schedule function fkob:schedules/trail_life 10t append
