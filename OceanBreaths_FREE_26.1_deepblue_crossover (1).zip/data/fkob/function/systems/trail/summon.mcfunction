execute if score Compat_Vanilla fkob.options matches 1 if predicate fkob:compatibility/vanilla_oceans run return run summon minecraft:marker ~ ~ ~ {Tags:["fkob.trail"]}
execute if score Compat_Terralith fkob.options matches 1 if predicate fkob:compatibility/terralith_oceans run return run summon minecraft:marker ~ ~ ~ {Tags:["fkob.trail"]}
