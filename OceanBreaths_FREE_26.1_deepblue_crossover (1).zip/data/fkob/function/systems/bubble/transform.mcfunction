tag @s add fkob.bubble.pop
tag @s remove fkob.bubble.prepare
particle minecraft:campfire_cosy_smoke ~ ~.1 ~ .3 .1 .3 .001 10
particle minecraft:campfire_signal_smoke ~ ~.3 ~ .05 .4 .05 .001 5
tp @s ~ ~.1 ~
