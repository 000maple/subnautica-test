execute unless predicate fkob:in_water/feet align y positioned ~ ~1.1 ~ run return run function fkob:systems/bubble/transform
tp @s ~ ~-1 ~
