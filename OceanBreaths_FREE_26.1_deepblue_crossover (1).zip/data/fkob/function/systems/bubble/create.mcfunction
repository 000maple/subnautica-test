function fkob:systems/bubble/summon
schedule function fkob:schedules/bubble_life 1s append

# restart air loop
execute if entity @p[scores={fkob.o2=1..}] run schedule function fkob:schedules/air 21t append
