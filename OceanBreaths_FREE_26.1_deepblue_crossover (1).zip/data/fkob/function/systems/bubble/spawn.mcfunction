summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}
execute as @n[type=minecraft:marker,tag=fkob.bubble.init,distance=..1] at @s run function fkob:systems/bubble/init
schedule function fkob:schedules/bubble_life 2s append
