$effect give @s minecraft:water_breathing $(O2) 0 true
