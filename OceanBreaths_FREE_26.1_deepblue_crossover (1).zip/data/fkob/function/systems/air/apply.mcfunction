# copy score in storage
execute store result storage fkob:options O2 int 1 run scoreboard players get @s fkob.o2

# get effect
function fkob:systems/air/effect with storage fkob:options
