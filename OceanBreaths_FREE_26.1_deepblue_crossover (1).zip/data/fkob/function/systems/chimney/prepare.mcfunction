tp @s ~ ~-.5 ~
execute if entity @n[type=minecraft:marker,tag=fkob.chimney,distance=1..96] unless entity @s[tag=chimney.force] run kill @s
execute unless predicate fkob:in_water/feet run function fkob:systems/chimney/transform
