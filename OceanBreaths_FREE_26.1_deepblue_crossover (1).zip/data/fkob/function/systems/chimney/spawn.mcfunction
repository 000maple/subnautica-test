summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.chimney","fkob.chimney.prepare","chimney.force","fkob.chimney.init"]}
execute as @n[type=minecraft:marker,tag=fkob.chimney.init,distance=..1] at @s run function fkob:systems/chimney/init
schedule function fkob:schedules/chimney_life 2s append
