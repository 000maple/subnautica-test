execute unless entity @n[type=minecraft:marker,tag=fkob.chimney,distance=..64] run function fkob:systems/chimney/summon
schedule function fkob:schedules/chimney_life 1s append

# restart air loop
execute if entity @p[scores={fkob.o2=1..}] run schedule function fkob:schedules/air 21t append
