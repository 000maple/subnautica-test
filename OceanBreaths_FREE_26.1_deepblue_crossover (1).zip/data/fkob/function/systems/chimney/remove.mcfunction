setblock ~ ~1 ~ minecraft:water
setblock ~ ~ ~ minecraft:water
kill @s[tag=fkob.chimney]
