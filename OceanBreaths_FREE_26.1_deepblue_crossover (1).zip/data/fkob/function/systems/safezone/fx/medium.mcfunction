# destroy
execute unless predicate fkob:in_water/feet run return run kill @s

# fx
particle minecraft:bubble ~ ~-.5 ~ 4 4 4 .05 30
particle minecraft:bubble_column_up ~ ~-2 ~ 2 2 2 0 5
particle minecraft:current_down ~ ~2 ~ 2 2 2 0 5

