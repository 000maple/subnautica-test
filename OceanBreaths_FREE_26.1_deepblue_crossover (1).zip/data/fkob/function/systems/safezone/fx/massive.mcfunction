# destroy
execute unless predicate fkob:in_water/feet run return run kill @s

# fx
particle minecraft:bubble ~ ~-.5 ~ 20 20 20 .05 150
particle minecraft:bubble_column_up ~ ~-4 ~ 15 6 15 0 30
particle minecraft:current_down ~ ~4 ~ 15 6 15 0 30

