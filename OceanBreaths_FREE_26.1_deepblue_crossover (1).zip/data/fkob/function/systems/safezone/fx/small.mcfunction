# destroy
execute unless predicate fkob:in_water/feet run return run kill @s

# fx
particle minecraft:bubble ~ ~-.5 ~ 1.8 1.8 1.8 .05 10
particle minecraft:bubble_column_up ~ ~-2 ~ 1 1 1 0 1
particle minecraft:current_down ~ ~2 ~ 1 1 1 0 1

