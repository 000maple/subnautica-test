# destroy
execute unless predicate fkob:in_water/feet run return run kill @s

# fx
particle minecraft:bubble ~ ~-.5 ~ 14 14 14 .05 60
particle minecraft:bubble_column_up ~ ~-3 ~ 8 4 8 0 20
particle minecraft:current_down ~ ~3 ~ 8 4 8 0 20

