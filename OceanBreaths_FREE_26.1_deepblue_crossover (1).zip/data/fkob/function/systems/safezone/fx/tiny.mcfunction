# destroy
execute unless predicate fkob:in_water/feet run return run kill @s

# fx
particle minecraft:bubble ~ ~-.3 ~ 0.5 0.5 0.5 .05 5
particle minecraft:bubble_column_up ~ ~-1.5 ~ .2 .2 .2 0 1
particle minecraft:current_down ~ ~1.3 ~ .2 .2 .2 0 1

