kill @s[tag=fkob.safezone]
