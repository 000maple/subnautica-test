# canceler
execute unless entity @n[type=minecraft:marker,tag=fkob.safezone,tag=safezone.active] run return 0

# sizes
execute as @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.tiny] at @s run function fkob:systems/safezone/fx/tiny
execute as @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.small] at @s run function fkob:systems/safezone/fx/small
execute as @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.medium] at @s run function fkob:systems/safezone/fx/medium
execute as @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.large] at @s run function fkob:systems/safezone/fx/large
execute as @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.massive] at @s run function fkob:systems/safezone/fx/massive

# loop
schedule function fkob:systems/safezone/loop_fx 10t replace
