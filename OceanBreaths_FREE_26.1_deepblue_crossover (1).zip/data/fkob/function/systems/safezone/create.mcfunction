# active
tag @e[type=minecraft:marker,tag=fkob.safezone,tag=!fkob.safezone.prepare,distance=..64] add safezone.active

# summon
execute unless entity @n[type=minecraft:marker,tag=fkob.safezone,distance=..64] run function fkob:systems/safezone/summon
schedule function fkob:schedules/safezone_life 6t append

# start loop
execute if entity @p[scores={fkob.o2=1..}] run schedule function fkob:schedules/air 21t append
execute if entity @n[type=minecraft:marker,tag=safezone.active] run schedule function fkob:systems/safezone/loop 61t append
