tag @s add fkob.safezone
tag @s remove fkob.safezone.prepare

execute align xyz run tp @s ~.5 ~.5 ~.5
particle minecraft:sneeze ~ ~ ~ .3 .6 .3 .001 1

$tag @s add safezone.$(size)
