# fx
execute positioned ^ ^-.2 ^.6 run particle minecraft:bubble_pop ~ ~ ~ .1 .1 .1 .01 3
execute if predicate fkobtool:rng/50 run playsound minecraft:block.pointed_dripstone.drip_water_into_cauldron player @s ~ ~ ~ 1 .5 .01


## air
scoreboard players operation #tmp fkob.o2 = @s fkob.o2

# canceler: if > max
execute if score #tmp fkob.o2 > Safezone.MaxO2 fkob.options run return 0

# add air
scoreboard players operation #tmp fkob.o2 += #4 fktool
execute if score #tmp fkob.o2 > Safezone.MaxO2 fkob.options run scoreboard players operation #tmp fkob.o2 = #90 fktool
scoreboard players operation @s fkob.o2 = #tmp fkob.o2
execute if score Compat.DeepBlue fkob.options matches 1 run scoreboard players set @s fkob.o2 1


# apply
function fkob:systems/air/apply
schedule function fkob:schedules/air 21t append
function #minecraft:oceanbreaths/on_safezone_consume
