tp @s ~ ~-3 ~

# canceler
execute if entity @n[type=minecraft:marker,tag=fkob.safezone,distance=1..64] unless entity @s[tag=safezone.force] run kill @s
execute unless predicate fkob:in_water/feet run kill @s
execute positioned ~ ~-8 ~ unless predicate fkob:in_water/feet run kill @s

# canceler: go deeper
execute unless predicate fkobtool:rng/30 run return 0

# find spot
function fkobtool:rng/get
execute if score Random fktool matches 95.. positioned ~ ~28 ~ if predicate fkob:in_water/feet at @s run return run function fkob:systems/safezone/transform {size:"massive"}
execute if score Random fktool matches 80.. positioned ~ ~20 ~ if predicate fkob:in_water/feet at @s run return run function fkob:systems/safezone/transform {size:"large"}
execute if score Random fktool matches 50.. positioned ~ ~12 ~ if predicate fkob:in_water/feet at @s run return run function fkob:systems/safezone/transform {size:"medium"}
execute if score Random fktool matches 30.. positioned ~ ~08 ~ if predicate fkob:in_water/feet at @s run return run function fkob:systems/safezone/transform {size:"small"}
execute if score Random fktool matches 01.. positioned ~ ~05 ~ if predicate fkob:in_water/feet at @s run return run function fkob:systems/safezone/transform {size:"tiny"}
