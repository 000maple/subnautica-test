# canceler
execute unless entity @n[type=minecraft:marker,tag=fkob.safezone,tag=safezone.active] run return 0

# sizes
execute as @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.active,tag=safezone.tiny] at @s as @a[gamemode=!spectator,distance=..02] at @s anchored eyes positioned ^ ^ ^ if predicate fkob:in_water/feet run function fkob:systems/safezone/consume
execute as @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.active,tag=safezone.small] at @s as @a[gamemode=!spectator,distance=..05] at @s anchored eyes positioned ^ ^ ^ if predicate fkob:in_water/feet run function fkob:systems/safezone/consume
execute as @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.active,tag=safezone.medium] at @s as @a[gamemode=!spectator,distance=..10] at @s anchored eyes positioned ^ ^ ^ if predicate fkob:in_water/feet run function fkob:systems/safezone/consume
execute as @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.active,tag=safezone.large] at @s as @a[gamemode=!spectator,distance=..16] at @s anchored eyes positioned ^ ^ ^ if predicate fkob:in_water/feet run function fkob:systems/safezone/consume
execute as @e[type=minecraft:marker,tag=fkob.safezone,tag=safezone.active,tag=safezone.massive] at @s as @a[gamemode=!spectator,distance=..28] at @s anchored eyes positioned ^ ^ ^ if predicate fkob:in_water/feet run function fkob:systems/safezone/consume

# loop
schedule function fkob:systems/safezone/loop 60t replace
schedule function fkob:systems/safezone/loop_fx 11t append
