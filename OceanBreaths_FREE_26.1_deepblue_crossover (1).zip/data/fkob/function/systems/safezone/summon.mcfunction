# canceler


# summon chance

execute unless score Compat.DeepBlue fkob.option matches 1 if predicate fkob:safezone_chance rotated ~-70 0 positioned ^ ^ ^30 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.safezone.prepare","fkob.safezone.init"]}
execute if predicate fkob:safezone_chance rotated ~000 0 positioned ^ ^ ^30 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.safezone.prepare","fkob.safezone.init"]}
execute unless score Compat.DeepBlue fkob.option matches 1 if predicate fkob:safezone_chance rotated ~070 0 positioned ^ ^ ^30 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.safezone.prepare","fkob.safezone.init"]}


# randomize pos
execute as @e[type=minecraft:marker,tag=fkob.safezone.init,sort=random,limit=1] if predicate fkobtool:rng/50 at @s facing entity @p eyes run tp @s ^ ^ ^03
execute as @e[type=minecraft:marker,tag=fkob.safezone.init,sort=random,limit=1] if predicate fkobtool:rng/50 at @s facing entity @p eyes run tp @s ^ ^ ^-3
execute as @e[type=minecraft:marker,tag=fkob.safezone.init,sort=random,limit=1] if predicate fkobtool:rng/50 at @s facing entity @p eyes run tp @s ^03 ^ ^
execute as @e[type=minecraft:marker,tag=fkob.safezone.init,sort=random,limit=1] if predicate fkobtool:rng/50 at @s facing entity @p eyes run tp @s ^-3 ^ ^
execute as @e[type=minecraft:marker,tag=fkob.safezone.init,sort=random,limit=1] if predicate fkobtool:rng/50 at @s facing entity @p eyes run tp @s ^ ^03 ^
execute as @e[type=minecraft:marker,tag=fkob.safezone.init,sort=random,limit=1] if predicate fkobtool:rng/50 at @s facing entity @p eyes run tp @s ^ ^-3 ^

# check
execute as @e[type=minecraft:marker,tag=fkob.safezone.init] at @s run function fkob:systems/safezone/init
