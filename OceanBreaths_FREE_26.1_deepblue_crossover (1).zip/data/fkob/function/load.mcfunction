# project
data modify storage fkob:text project.name set value "OceanBreaths"
data modify storage fkob:text project.compatibility set value "26.1+"
data modify storage fkob:text project.print set value [{"text":"[","bold":true,"color":"gold","hover_event":{"action":"show_text","value":[{"storage":"fktool:info","nbt":"load.devby","interpret":true}]}},{"storage":"fkob:text","nbt":"project.name","interpret":true,"bold":true,"color":"gold"},{"text":"] ","bold":true,"color":"gold","hover_event":{"action":"show_text","value":[{"storage":"fktool:info","nbt":"load.devby","interpret":true}]}}]

# scores
scoreboard objectives add fkob.options dummy {"text":"OceanBreaths Options","color":"#008058"}
scoreboard objectives add fkob.o2 dummy {"text":"O² Tank","color":"#008058"}

# constants


# config
function fkob:lang/us
function fkob:properties
function fkob:schedules/list
schedule function fkob:compatibility 21t

# display
tellraw @a ["",{"storage":"fkob:text","nbt":"project.print","interpret":true},{"storage":"fktool:info","nbt":"load.enabled","interpret":true},{"text":" ("},{"storage":"fkob:text","nbt":"project.compatibility","interpret":true},{"text":"). "},{"storage":"fktool:info","nbt":"load.options","interpret":true},{"text":"[click here]","bold":true,"color":"aqua","click_event":{"action":"suggest_command","command":"/function fkob:options/get"}}]
tellraw @a ["",{"storage":"fkob:text","nbt":"project.print","interpret":true},{"storage":"fktool:info","nbt":"load.networks","interpret":true}]
tellraw @a ["",{"storage":"fkob:text","nbt":"project.print","interpret":true},{"storage":"fktool:info","nbt":"load.free","interpret":true}]
