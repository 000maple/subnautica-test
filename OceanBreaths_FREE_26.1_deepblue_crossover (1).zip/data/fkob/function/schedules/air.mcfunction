# consume air
scoreboard players remove @a[scores={fkob.o2=1..}] fkob.o2 1
scoreboard players reset @a[scores={fkob.o2=..0}] fkob.o2

# apply air
execute as @a[scores={fkob.o2=1..}] run function fkob:systems/air/apply

# loop
execute if entity @p[scores={fkob.o2=1..}] run schedule function fkob:schedules/air 20t replace
