function fkob:tick
function fkob:schedules/air
function fkob:schedules/bubble_life
function fkob:schedules/chimney_life
function fkob:schedules/safezone_life
function fkob:schedules/oxidifer_life
