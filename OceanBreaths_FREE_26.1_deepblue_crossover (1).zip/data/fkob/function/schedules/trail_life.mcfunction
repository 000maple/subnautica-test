# display fx & die
execute as @e[type=minecraft:marker,tag=fkob.trail] at @s run function fkob:systems/trail/life

# add trail particle
execute if score Trail.Enable fkob.options matches 1 as @a[gamemode=!spectator] at @s if predicate fkob:ocean_ground run function fkob:systems/trail/summon

# loop
execute if entity @n[type=minecraft:marker,tag=fkob.trail] run schedule function fkob:schedules/trail_life 6t replace
