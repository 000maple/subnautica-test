execute as @e[type=minecraft:marker,tag=fkob.bubble.prepare] at @s run function fkob:systems/bubble/prepare
execute as @e[type=minecraft:marker,tag=fkob.bubble.pop] at @s run function fkob:systems/bubble/pop
execute as @a[gamemode=!spectator,predicate=fkob:in_water/feet] at @s anchored eyes positioned ^ ^ ^ if entity @e[type=minecraft:marker,tag=fkob.bubble.pop,distance=..1.5] run function fkob:systems/bubble/consume

execute if entity @n[type=minecraft:marker,tag=fkob.bubble] run schedule function fkob:schedules/bubble_life 5t replace
