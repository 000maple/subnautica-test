execute as @e[type=minecraft:marker,tag=fkob.chimney.prepare] at @s run function fkob:systems/chimney/prepare
execute as @e[type=minecraft:marker,tag=fkob.chimney.pop] at @s run function fkob:systems/chimney/pop
execute as @a[gamemode=!spectator,predicate=fkob:in_water/eye] at @s anchored eyes positioned ^ ^ ^ if entity @n[type=minecraft:marker,tag=fkob.chimney.pop,distance=..1.5] run function fkob:systems/chimney/consume

execute at @a if entity @n[type=minecraft:marker,tag=fkob.chimney,distance=..64] run schedule function fkob:schedules/chimney_life 5t replace
