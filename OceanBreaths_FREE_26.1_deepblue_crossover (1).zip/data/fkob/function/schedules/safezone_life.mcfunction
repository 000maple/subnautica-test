execute as @e[type=minecraft:marker,tag=fkob.safezone.prepare] at @s run function fkob:systems/safezone/prepare

execute if entity @n[type=minecraft:marker,tag=fkob.safezone.prepare] run schedule function fkob:schedules/safezone_life 5t replace
