function fkob:systems/bubble/create
function fkob:systems/chimney/create
function fkob:systems/safezone/create
function fkob:systems/oxidizer/detect
execute if score Trail.Enable fkob.options matches 1 run function fkob:systems/trail/detect
