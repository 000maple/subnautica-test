scoreboard players set Bubble.Enable fkob.options 1
scoreboard players set Bubble.Spawn.Multiplier fkob.options 2
scoreboard players set Bubble.O2 fkob.options 30
scoreboard players set Bubble.MaxO2 fkob.options 90
scoreboard players set Chimney.Enable fkob.options 1
scoreboard players set Chimney.Spawn.Multiplier fkob.options 2
scoreboard players set Chimney.O2 fkob.options 3
scoreboard players set Chimney.MaxO2 fkob.options 90
scoreboard players set Oxidizer.Enable fkob.options 1
scoreboard players set Oxidizer.Fx fkob.options 1
scoreboard players set Safezone.Enable fkob.options 1
scoreboard players set Safezone.Fx.Sneeze fkob.options 0
scoreboard players set Safezone.Spawn.Multiplier fkob.options 2
scoreboard players set Safezone.O2 fkob.options 4
scoreboard players set Safezone.MaxO2 fkob.options 90
scoreboard players set Trail.Enable fkob.options 1

tellraw @s ["",{"storage":"fkob:text","nbt":"project.print","interpret":true},{"text":"Options have been reset","color":"red"}]
