# use: tellraw @a {"storage":"fkob:text","nbt":"log.test","interpret":true}

# log
#data modify storage fkob:text bubble.name set value ["",{"storage":"fkob:text","nbt":"project.print","interpret":true},{"selector":"@s","color":"red"},{"text":" -> found player_head","color":"red"}]
