### OceanBreaths Datapack
###
### Developped by FunkyToc
### With love
### And a big amount of time


## Bubble

# Allow bubbles to spawn at the ocean floor
# 0 : disable
# 1 : enable
execute unless score Bubble.Enable fkob.options matches 0.. run scoreboard players set Bubble.Enable fkob.options 1

# Bubble spawn rate multiplier
# Default : 2
# Range : 1 - 3
execute unless score Bubble.Spawn.Multiplier fkob.options matches 0.. run scoreboard players set Bubble.Spawn.Multiplier fkob.options 2

# Oxygen recovered per bubble (seconds, per bubble)
# Default : 30
# Range : 1 - 999
execute unless score Bubble.O2 fkob.options matches 0.. run scoreboard players set Bubble.O2 fkob.options 30

# Max oxygen stack using bubbles (seconds)
# Default : 90
# Range : 1 - 999
execute unless score Bubble.MaxO2 fkob.options matches 0.. run scoreboard players set Bubble.MaxO2 fkob.options 90


## Chimney

# Allow chimneys to spawn at the ocean floor
# 0 : disable
# 1 : enable
execute unless score Chimney.Enable fkob.options matches 0.. run scoreboard players set Chimney.Enable fkob.options 1

# Chimney spawn rate multiplier
# Default : 2
# Range : 1 - 3
execute unless score Chimney.Spawn.Multiplier fkob.options matches 0.. run scoreboard players set Chimney.Spawn.Multiplier fkob.options 2

# Oxygen recovered staying close to the chimney (seconds, per 5 ticks)
# Default : 3
# Range : 1 - 999
execute unless score Chimney.O2 fkob.options matches 0.. run scoreboard players set Chimney.O2 fkob.options 3

# Max oxygen stack using chimneys (seconds)
# Default : 90
# Range : 1 - 999
execute unless score Chimney.MaxO2 fkob.options matches 0.. run scoreboard players set Chimney.MaxO2 fkob.options 90


## Safezone

# Allow safezones to spawn in deep oceans
# Default : 1
# 0 : disable
# 1 : enable
execute unless score Safezone.Enable fkob.options matches 0.. run scoreboard players set Safezone.Enable fkob.options 1

# Add a sneeze particle at safezone's center to improve visibility
# Default : 0
# 0 : disable
# 1 : enable
execute unless score Safezone.Fx.Sneeze fkob.options matches 0.. run scoreboard players set Safezone.Fx.Sneeze fkob.options 0

# Safezone spawn rate multiplier
# Default : 2
# Range : 1 - 3
execute unless score Safezone.Spawn.Multiplier fkob.options matches 0.. run scoreboard players set Safezone.Spawn.Multiplier fkob.options 2

# Oxygen recovered staying in the safezone (seconds, per 3 seconds)
# Default : 4
# Range : 1 - 999
execute unless score Safezone.O2 fkob.options matches 0.. run scoreboard players set Safezone.O2 fkob.options 4

# Max oxygen stack using safezone (seconds)
# Default : 90
# Range : 1 - 999
execute unless score Safezone.MaxO2 fkob.options matches 0.. run scoreboard players set Safezone.MaxO2 fkob.options 90


## Oxidizer

# Enable oxidizer structure to create a safezone (require Safezone.Enable)
# Default : 1
# 0 : disable
# 1 : enable
execute unless score Oxidizer.Enable fkob.options matches 0.. run scoreboard players set Oxidizer.Enable fkob.options 1

# Add particles on the Oxidizer's rod
# Default : 1
# 0 : disable
# 1 : enable
execute unless score Oxidizer.Fx fkob.options matches 0.. run scoreboard players set Oxidizer.Fx fkob.options 1


## Cosmetic

# Cosmetic dust trails when walking on the ocean floor
# Default : 1
# 0 : disable
# 1 : enable
execute unless score Trail.Enable fkob.options matches 0.. run scoreboard players set Trail.Enable fkob.options 1
