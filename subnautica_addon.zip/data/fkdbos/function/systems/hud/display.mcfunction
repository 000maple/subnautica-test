# Disabled by SubnauticaMC addon: HUD is now handled by the SubnauticaMC plugin.
# This overrides DBOS's original hud/display.mcfunction (single resource, non-mergeable)
# without modifying the original DBOS pack file itself.
